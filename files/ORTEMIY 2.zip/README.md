# Ortemiy Workspace для OpenClaw

Это готовый воркспейс для агента **Ортемий** — цифрового двойника Артемия Сердитова — под OpenClaw.

## Состав

```
ortemiy-workspace/
├── IDENTITY.md              ← имя, vibe, железные факты биографии
├── SOUL.md                  ← голос, тон, стиль (МАИН файл личности)
├── AGENTS.md                ← операционные правила: workflow постов, память
├── USER.md                  ← шаблон под пользователя (заполняется в первой сессии)
├── MEMORY.md                ← долгосрочная память (уже с базой по Артемию)
├── TOOLS.md                 ← заметки по каналам, референсам
├── HEARTBEAT.md             ← чек-лист проактивных проверок
├── BOOTSTRAP.md             ← ритуал первого запуска (удалить после выполнения)
├── memory/                  ← daily-заметки, создаются автоматически
├── avatars/                 ← сюда закинуть ortemiy.png
└── openclaw.json.sample     ← стартовый конфиг (положить в ~/.openclaw/openclaw.json)
```

## Деплой — 7 шагов

### 1. Поставить OpenClaw

**macOS / Linux:**
```bash
curl -fsSL https://openclaw.ai/install.sh | bash
```

**Windows (PowerShell):**
```powershell
iwr -useb https://openclaw.ai/install.ps1 | iex
```

Нужен Node.js 24 (или 22.14+).

### 2. Пройти onboard

```bash
openclaw onboard --install-daemon
```

Мастер спросит провайдера — выбираешь **Anthropic**. Кидаешь API-ключ (забирается в защищённое хранилище, не в конфиг).

### 3. Положить воркспейс

Дефолтное место — `~/.openclaw/workspace`. Либо копируешь содержимое этой папки туда:

```bash
cp -r ortemiy-workspace/* ~/.openclaw/workspace/
```

Либо переопределяешь путь в конфиге (см. следующий шаг).

### 4. Применить конфиг

Переименуй `openclaw.json.sample` в `openclaw.json` и положи в `~/.openclaw/`:

```bash
cp ortemiy-workspace/openclaw.json.sample ~/.openclaw/openclaw.json
```

Внутри — дефолтная модель (`claude-opus-4-7`), таймзона Europe/Moscow, формат времени 24ч. Правь под себя если надо.

### 5. Закинуть референсы

Создай папку `references/` внутри воркспейса и положи туда файлы из Claude-проекта:

```
references/
├── corpus/
│   └── messages.html                       ← дамп ТГ-канала
├── best-packs/
│   └── SW_BAND-пачка-постов-30-млн.docx    ← золотой эталон
├── golden-phrases.md                       ← банк фраз
├── golden-phrases-flat.txt
└── golden-phrases-filtered.txt             ← НЕ использовать, только для справки
```

**Без этой папки агент будет промахиваться со стилем.** Это не декорация — это его рабочий эталон голоса.

### 6. Проверить и запустить

```bash
openclaw gateway status       # Gateway жив? Порт 18789?
openclaw dashboard            # Открыть Control UI в браузере
```

Первое сообщение напиши в чате — агент должен **самостоятельно** прочитать `BOOTSTRAP.md`, пройти ритуал, познакомиться с тобой и удалить BOOTSTRAP после выполнения.

Ожидаемое первое приветствие от агента — примерно такого формата:

> Ну здарова, котятки. Я тут. Разобрался с файлами, понял кто я, щас буду разбираться с тобой. Как к тебе обращаться и чем занимаешься? И сразу договоримся — мат норм или душить по-культурному?

Если оно приветствует как «AI-ассистент Anthropic» — значит SOUL.md не подгрузился. Смотри `openclaw logs`.

### 7. (Опционально) Подключить Telegram

```bash
openclaw channels add telegram
```

Мастер спросит BotFather-токен. Всё. Агент начнёт отвечать в твоём ТГ-боте в голосе Ортемия.

## Что делать если голос «плывёт»

1. **Проверь что SOUL.md и AGENTS.md реально подгружены.** В Control UI есть `/context list` — он покажет, сколько токенов сожрал каждый bootstrap-файл. Если SOUL.md = 0 — он не подгрузился.
2. **Размер файлов.** Дефолт `bootstrapMaxChars: 20000` на файл. SOUL.md сейчас ~11к — проходит. Если разрастётся больше 20к — нужно либо поднимать лимит в конфиге, либо резать.
3. **Референсы не подключены.** Если `references/` пустая — агент пишет «от головы», а не «от голоса». Закинь корпус.
4. **Модель слабая.** На Haiku голос Артемия звучит усреднённо. На Sonnet — уже хорошо. На Opus — лучше всего.

## Git backup (рекомендуется)

OpenClaw доки советуют хранить воркспейс в приватном git-репо:

```bash
cd ~/.openclaw/workspace
git init
git add AGENTS.md SOUL.md IDENTITY.md USER.md MEMORY.md TOOLS.md HEARTBEAT.md memory/
git commit -m "Initial ortemiy workspace"
# Создай приватный репо на GitHub/GitLab, потом:
git remote add origin <private-url>
git push -u origin main
```

**В `.gitignore` добавь:**
```
.DS_Store
.env
references/corpus/         # дамп ТГ-канала — приватка
```

Сам `~/.openclaw/` (конфиг, credentials, sessions) в репо НЕ клади — там токены.

## Дальше

Всё, что может потребоваться на ходу — `openclaw docs` в терминале открывает локальную доку, либо https://docs.openclaw.ai .

Удачи. Ортемий передаёт привет 🤝
