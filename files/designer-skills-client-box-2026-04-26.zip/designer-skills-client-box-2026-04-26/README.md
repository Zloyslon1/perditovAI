# Designer Skills — Client Ready Box

Дата сборки: 2026-04-26

Внутри:
- `skills/` — сырые папки skills, уже очищенные от приватных ключей, личных путей и внутренних ID.
- `packages/` — те же skills, упакованные в `.skill` файлы.

## Что вошло

- `audience-lens`
- `carousel`
- `chatplace`
- `claude-design-producer`
- `design-toolkit`
- `gsap`
- `heygen`
- `hyperframes`
- `hyperframes-cli`
- `hyperframes-registry`
- `image-gen`
- `kie-image`
- `laozhang-onboarding`
- `nano-banana`
- `nano-banana-pro-prompts`
- `notebooklm-research`
- `notion-master`
- `obsidian`
- `pixel-reel-maker`
- `reel-maker`
- `remotion-motion-design`
- `timelapse-creator`
- `ui-ux-pro-max`
- `veo-video`
- `video-editor`
- `video-gen`
- `website-to-hyperframes`

## Что было вычищено

- hardcoded API keys / tokens
- личные absolute paths
- внутренние bot IDs / usernames / Notion IDs
- личные voice IDs и брендовые приватные референсы

## Быстрая установка

### Вариант A — как папки
1. Открой у себя папку агента.
2. Скопируй нужные папки из `skills/` в локальную директорию `skills/` этого агента.
3. Перезапусти агент / gateway, если платформа кеширует skills.

### Вариант B — как `.skill` пакеты
1. Возьми нужный файл из `packages/`.
2. Распакуй его как zip или импортируй тем способом, который принят в вашей сборке OpenClaw.
3. После импорта проверь, что папка skill появилась в `skills/`.

## Что клиенту надо настроить самому

### API keys / env
- `LAOZHANG_API_KEY`
- `KIE_API_KEY`
- `CHATPLACE_API_KEY`
- `NOTION_API_KEY`
- `GEMINI_API_KEY`
- `GOOGLE_API_KEY` (если используете Gemini через Google route)
- `ELEVENLABS_API_KEY`
- `ELEVENLABS_VOICE_ID_RU`
- `ELEVENLABS_VOICE_ID_EN`
- `GROQ_API_KEY`

### Локальные зависимости, если нужны конкретные skills
- `notebooklm` CLI — должен быть установлен и доступен в `PATH`
- `gcloud` auth / Google Stitch MCP — клиент подключает свой проект
- `ffmpeg`, `python3`, `node`, `npm/npx` — для видео и motion skills
- Remotion project path — задать свой `<REMOTION_PROJECT_DIR>`
- Любые face/reference images — подставлять свои пути вместо плейсхолдеров

## Проверка после установки

- открыть нужный `SKILL.md`
- проверить, что все плейсхолдеры заменены на клиентские значения
- прогнать 1 живой smoke test на каждый провайдерный skill:
  - `laozhang-onboarding`
  - `kie-image`
  - `chatplace`
  - `notion-master`
  - `notebooklm-research` (если нужен)

## Важно

Эта коробка очищена от приватных данных, но не подставляет клиентские ключи автоматически.
Перед боевым использованием клиент должен заменить плейсхолдеры и пройти свои авторизации.
