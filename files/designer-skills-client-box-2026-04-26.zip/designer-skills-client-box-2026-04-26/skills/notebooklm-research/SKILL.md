---
name: notebooklm-research
description: "RAG-ресёрч и генерация контента через Google NotebookLM. Создание блокнотов, загрузка источников (URL, PDF, YouTube, текст), вопросы по документам с цитатами, генерация подкастов/видео/слайдов/квизов/инфографики/mind map. Бесплатный RAG с контекстом 20M+ токенов. Активируется на: 'notebooklm', 'ресёрч', 'research notebook', 'создай подкаст из', 'проанализируй документы', 'сделай квиз', 'флеш-карточки', 'mind map из источников', 'загрузи в блокнот', 'deep research'."
---

# NotebookLM Research — RAG-система для глубокого ресёрча

Полный программный доступ к Google NotebookLM через CLI `notebooklm`.
Gemini обрабатывает документы бесплатно, агент оркестрирует процесс.

## CLI путь

```
notebooklm
```

Использовать полный путь или алиас `notebooklm` если в PATH.

## Авторизация

Перед первым использованием — один раз:
```bash
notebooklm login          # откроется браузер для Google OAuth
notebooklm list           # проверить что авторизация работает
```

Сессия живёт несколько недель. При ошибках авторизации → `notebooklm login` повторно.
Данные хранятся в `~/.notebooklm/` — не коммитить в git.

## Основной рабочий процесс

### 1. Создать блокнот
```bash
notebooklm create "Тема исследования" --json
# → {"id": "abc123...", "title": "..."}
```

### 2. Установить контекст
```bash
notebooklm use <notebook_id>
```

### 3. Добавить источники
```bash
notebooklm source add "https://example.com"       # URL
notebooklm source add "./document.pdf"             # файл
notebooklm source add "https://youtube.com/..."    # YouTube
notebooklm source add --text "Мои заметки" --title "Заметки"  # текст
```

Лимит: до 50 источников на блокнот (бесплатный план).
Ждать индексации: `notebooklm source list --json` → все `status: "ready"`.

### 4. Задать вопросы (ответы строго по источникам, с цитатами)
```bash
notebooklm ask "Какие ключевые выводы?"
notebooklm ask "Есть ли противоречия между источниками?" --json  # с ссылками на цитаты
notebooklm ask "Сравни подходы" -s src_id1 -s src_id2  # по конкретным источникам
```

### 5. Генерировать контент
```bash
notebooklm generate audio "сделай обзор"           # подкаст (10-20 мин генерации)
notebooklm generate video --style whiteboard        # видео
notebooklm generate slide-deck                      # слайды
notebooklm generate infographic --orientation portrait  # инфографика
notebooklm generate report --format study-guide     # отчёт
notebooklm generate mind-map                        # mind map (мгновенно)
notebooklm generate quiz --difficulty hard           # квиз
notebooklm generate flashcards                      # флеш-карточки
notebooklm generate data-table "описание таблицы"   # таблица данных
```

### 6. Скачать результаты
```bash
notebooklm download audio ./podcast.mp3
notebooklm download video ./video.mp4
notebooklm download slide-deck ./slides.pdf         # или --format pptx
notebooklm download report ./report.md
notebooklm download mind-map ./map.json
notebooklm download quiz ./quiz.json                # или --format markdown
notebooklm download flashcards ./cards.md --format markdown
notebooklm download data-table ./data.csv
```

## Deep Research (веб-поиск через NotebookLM)

```bash
# Быстрый поиск (5-10 источников, секунды)
notebooklm source add-research "тема" --mode fast

# Глубокий поиск (20+ источников, 2-5 мин)
notebooklm source add-research "тема" --mode deep --no-wait
notebooklm research wait --import-all --timeout 300
```

## Важные правила

- **Автоматически** (без подтверждения): status, list, source list/add, ask, use, create
- **С подтверждением**: delete, generate *, download * (пишет на диск)
- Генерация audio/video — асинхронная, 10-45 мин. Запускать и проверять позже через `artifact list`
- Mind map — единственная синхронная генерация
- ~50 запросов/день на бесплатном аккаунте
- `--json` флаг для машиночитаемого вывода

## Форматы и стили

- **Подкаст**: `--format deep-dive|brief|critique|debate`, `--length short|default|long`
- **Видео**: `--style classic|whiteboard|kawaii|anime|watercolor|retro-print|heritage|paper-craft`
- **Отчёт**: `--format briefing-doc|study-guide|blog-post|custom`
- **Слайды**: `--format detailed|presenter`, `--length default|short`
- **Язык вывода**: `--language ru` (или `notebooklm language set ru` глобально)

## Обработка ошибок

| Ошибка | Действие |
|--------|----------|
| Auth/cookie error | `notebooklm login` |
| "No notebook context" | `notebooklm use <id>` |
| Rate limiting | Подождать 5-10 мин, повторить |
| Download fails | Проверить `artifact list` — может ещё генерируется |

## Подробный справочник команд

→ Полная таблица команд, exit codes, JSON-схемы, параллельная работа: см. `references/cli-reference.md`
