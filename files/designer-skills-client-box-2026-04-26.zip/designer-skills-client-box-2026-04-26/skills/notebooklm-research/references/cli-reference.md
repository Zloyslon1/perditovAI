# NotebookLM CLI — Полный справочник

## Все команды

| Задача | Команда |
|--------|---------|
| Авторизация | `notebooklm login` |
| Диагностика авторизации | `notebooklm auth check --test` |
| Список блокнотов | `notebooklm list --json` |
| Создать блокнот | `notebooklm create "Title" --json` |
| Удалить блокнот | `notebooklm delete <id>` |
| Переименовать | `notebooklm rename <id> "New Title"` |
| Установить контекст | `notebooklm use <id>` |
| Показать контекст | `notebooklm status` |
| Добавить URL | `notebooklm source add "https://..." --json` |
| Добавить файл | `notebooklm source add ./file.pdf --json` |
| Добавить YouTube | `notebooklm source add "https://youtube.com/..." --json` |
| Добавить текст | `notebooklm source add --text "текст" --title "Заголовок"` |
| Добавить из Drive | `notebooklm source add-drive "query"` |
| Список источников | `notebooklm source list --json` |
| Полный текст источника | `notebooklm source fulltext <source_id>` |
| Гайд по источнику | `notebooklm source guide <source_id>` |
| Ждать индексации | `notebooklm source wait <source_id> --timeout 120` |
| Обновить источник | `notebooklm source refresh <source_id>` |
| Удалить источник | `notebooklm source delete <source_id>` |
| Быстрый веб-поиск | `notebooklm source add-research "query"` |
| Глубокий поиск | `notebooklm source add-research "query" --mode deep --no-wait` |
| Статус поиска | `notebooklm research status` |
| Ждать поиск + импорт | `notebooklm research wait --import-all --timeout 300` |
| Вопрос | `notebooklm ask "вопрос"` |
| Вопрос с цитатами | `notebooklm ask "вопрос" --json` |
| По конкретным источникам | `notebooklm ask "вопрос" -s id1 -s id2` |
| Продолжить беседу | `notebooklm ask "вопрос" -c <conversation_id>` |
| Сохранить ответ как заметку | `notebooklm ask "вопрос" --save-as-note` |
| История чата | `notebooklm history` |
| Сохранить историю | `notebooklm history --save --note-title "Заголовок"` |
| Генерация подкаста | `notebooklm generate audio "инструкции"` |
| Генерация видео | `notebooklm generate video "инструкции" --style whiteboard` |
| Генерация слайдов | `notebooklm generate slide-deck` |
| Редактировать слайд | `notebooklm generate revise-slide "prompt" --artifact <id> --slide 0` |
| Генерация инфографики | `notebooklm generate infographic --orientation portrait` |
| Генерация отчёта | `notebooklm generate report --format study-guide` |
| Генерация mind map | `notebooklm generate mind-map` |
| Генерация таблицы | `notebooklm generate data-table "описание"` |
| Генерация квиза | `notebooklm generate quiz --difficulty hard` |
| Генерация карточек | `notebooklm generate flashcards --difficulty medium` |
| Список артефактов | `notebooklm artifact list --json` |
| Ждать артефакт | `notebooklm artifact wait <artifact_id> --timeout 600` |
| Скачать аудио | `notebooklm download audio ./file.mp3` |
| Скачать видео | `notebooklm download video ./file.mp4` |
| Скачать слайды (PDF) | `notebooklm download slide-deck ./slides.pdf` |
| Скачать слайды (PPTX) | `notebooklm download slide-deck ./slides.pptx --format pptx` |
| Скачать отчёт | `notebooklm download report ./report.md` |
| Скачать mind map | `notebooklm download mind-map ./map.json` |
| Скачать квиз (JSON) | `notebooklm download quiz ./quiz.json` |
| Скачать квиз (MD) | `notebooklm download quiz ./quiz.md --format markdown` |
| Скачать карточки | `notebooklm download flashcards ./cards.md --format markdown` |
| Скачать таблицу | `notebooklm download data-table ./data.csv` |
| Список языков | `notebooklm language list` |
| Текущий язык | `notebooklm language get` |
| Установить язык | `notebooklm language set ru` |
| Шаринг | `notebooklm share status` |

## Exit codes

| Код | Значение |
|-----|----------|
| 0 | Успех |
| 1 | Ошибка (не найден, failed) |
| 2 | Таймаут (только wait-команды) |

## JSON-схемы ответов

**list --json:**
```json
{"notebooks": [{"id": "...", "title": "...", "created_at": "..."}]}
```

**source add --json:**
```json
{"source_id": "...", "title": "...", "status": "processing"}
```

**source list --json:**
```json
{"sources": [{"id": "...", "title": "...", "status": "ready|processing|error"}]}
```

**ask --json:**
```json
{"answer": "...", "conversation_id": "...", "turn_number": 1, "references": [{"source_id": "...", "citation_number": 1, "cited_text": "..."}]}
```

**generate --json:**
```json
{"task_id": "...", "status": "pending"}
```

**artifact list --json:**
```json
{"artifacts": [{"id": "...", "title": "...", "type": "Audio Overview", "status": "in_progress|completed"}]}
```

## Параллельная работа (несколько агентов)

`notebooklm use` пишет контекст в общий файл — при параллельной работе будет конфликт.

**Решение:** всегда указывать `-n <notebook_id>` или `--notebook <notebook_id>`:
```bash
notebooklm ask "вопрос" --notebook <id>
notebooklm artifact wait <artifact_id> -n <id>
notebooklm download audio ./file.mp3 -n <id> -a <artifact_id>
```

Или изолировать через `NOTEBOOKLM_HOME`:
```bash
export NOTEBOOKLM_HOME=/tmp/agent-$ID
```

## Partial ID

Можно использовать первые 6+ символов UUID:
```bash
notebooklm use abc123   # совпадёт с abc123de-f456-...
```

## Время операций

| Операция | Время | Таймаут |
|----------|-------|---------|
| Индексация источника | 30с — 10 мин | 600с |
| Быстрый поиск | 30с — 2 мин | 180с |
| Глубокий поиск | 15 — 30+ мин | 1800с |
| Mind map | мгновенно | — |
| Квиз, карточки | 5 — 15 мин | 900с |
| Отчёт, таблица | 5 — 15 мин | 900с |
| Аудио (подкаст) | 10 — 20 мин | 1200с |
| Видео | 15 — 45 мин | 2700с |

## Лимиты бесплатного плана

- ~50 запросов/день
- До 50 источников на блокнот
- Генерация может быть ограничена rate limiting
- Обходной путь: дополнительный Google-аккаунт
