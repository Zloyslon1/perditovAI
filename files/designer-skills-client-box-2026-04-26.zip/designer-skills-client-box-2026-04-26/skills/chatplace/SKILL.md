---
name: chatplace
description: "ChatPlace MCP интеграция — полное управление ботами Instagram/Telegram/TikTok: автоматизации, рассылки, аналитика, воронки, AI-агенты, теги, переменные, шаблоны, медиафайлы. Активируется на: 'chatplace', 'чатплейс', 'бот instagram', 'рассылка', 'автоматизация бота', 'mcp chatplace', 'воронка в боте'."
---

# ChatPlace MCP Integration

Платформа автоматизации Instagram, Telegram и TikTok: чат-боты, геймификация, воронки, рассылки, AI-агенты.

## Настройка

API-ключ: `CHATPLACE_API_KEY` (клиент подставляет свой)
MCP endpoint: `https://mcp.chatplace.io/mcp`
Авторизация: `Bearer <API_KEY>`

## Скрипт

**Путь:** `scripts/mcp_client.sh`

```bash
export CHATPLACE_API_KEY="cpk_..."

# Инициализация сессии
./scripts/mcp_client.sh init

# Список инструментов
./scripts/mcp_client.sh tools

# Вызов инструмента
./scripts/mcp_client.sh call <tool_name> '{"key":"value"}'

# Сброс сессии
./scripts/mcp_client.sh reset
```

## Боты в аккаунте

Список ботов зависит от аккаунта клиента. Получить его после подключения ключа:

```bash
./scripts/mcp_client.sh call bots.list '{}'
```

Для всех примеров ниже подставляй свой `botId`.

## Инструменты (94 tools)

### 🤖 Боты (4)
| Tool | Описание |
|------|----------|
| `bots.list` | Список ботов |
| `bots.get` | Информация о боте (botId) |
| `bots.register_telegram` | Зарегистрировать TG бота (token) |
| `bots.update_telegram` | Обновить токен TG бота |

### ⚙️ Автоматизации — Управление (12)
| Tool | Описание |
|------|----------|
| `automations.list` | Список автоматизаций (botId) |
| `automations.get` | Детали автоматизации |
| `automations.getDetail` | Полная структура: цепочка, триггеры, кнопки, действия, условия |
| `automations.create` | Создать автоматизацию (draft) |
| `automations.update` | Переименовать |
| `automations.delete` | Удалить |
| `automations.changeStatus` | Активировать/приостановить ("active"/"paused") |
| `automations.quickSetup` | Быстрая воронка одним вызовом (2 шаблона: base, checkSubscription) |
| `automations.analytics` | Аналитика: клиенты, конверсии за период |
| `automations.quickSetupAnalytics` | Аналитика быстрой воронки: клики, CTR |
| `automations.stepAnalytics` | **NEW** Воронка по шагам: клиенты, продажи, отписки |
| `automations.listWithStats` | **NEW** Список автоматизаций со статистикой |

### 📊 Общая аналитика (1)
| Tool | Описание |
|------|----------|
| `automations.totalReport` | **NEW** Дашборд компании: клиенты, взаимодействия, активные чаты (week-over-week) |

### 🔧 Шаги автоматизации (4) — NEW!
| Tool | Описание |
|------|----------|
| `automations.steps.create` | Создать шаг в автоматизации |
| `automations.steps.update` | Обновить шаг |
| `automations.steps.delete` | Удалить шаг |
| `automations.steps.setStart` | Установить стартовый шаг |

### 💬 Сообщения в автоматизации (7) — NEW!
| Tool | Описание |
|------|----------|
| `automations.messages.create` | Создать блок (message/condition/action/note) |
| `automations.messages.update` | Обновить текст блока |
| `automations.messages.delete` | Удалить блок |
| `automations.messages.connect` | Соединить блоки стрелкой (или разъединить) |
| `automations.messages.attachMedia` | Прикрепить медиафайл к сообщению |
| `automations.messages.detachMedia` | Открепить медиафайл |

### 🔘 Inline-кнопки (5) — NEW!
| Tool | Описание |
|------|----------|
| `automations.inlineButtons.create` | Создать кнопку (url или quick-answer) |
| `automations.inlineButtons.setup` | Настроить тип: normal/url/payment (скидки, методы оплаты) |
| `automations.inlineButtons.update` | Обновить текст/URL кнопки |
| `automations.inlineButtons.delete` | Удалить кнопку |
| `automations.buttons.connect` | Соединить кнопку со следующим блоком |

### ⚡ Действия (actions) (2) — NEW!
| Tool | Описание |
|------|----------|
| `automations.actions.setup` | Настроить действия на блоке (add_tag, remove_tag, delay, http_request и др.) |
| `automations.actions.delete` | Удалить действие |

### 🔀 Условия (conditions) (3) — NEW!
| Tool | Описание |
|------|----------|
| `automations.conditionButtons.create` | Создать ветку "подходит" (fit) — "не подходит" создаётся автоматически |
| `automations.conditions.setup` | Настроить условия (has_tags, check_variable и др.) |
| `automations.conditions.delete` | Удалить ветку условия |

### 🎯 Триггеры (4) — NEW!
| Tool | Описание |
|------|----------|
| `automations.triggers.set` | Установить триггеры и ключевые слова (заменяет существующие) |
| `automations.triggers.listInstagramMedia` | Список постов IG для привязки триггеров к конкретным публикациям |
| `automations.triggers.listTelegramChannels` | Каналы TG для проверки подписки |

### 📖 Справочники (3) — NEW!
| Tool | Описание |
|------|----------|
| `automations.reference.actions` | Все доступные действия (labels, поля, схемы) |
| `automations.reference.conditions` | Все доступные условия |
| `automations.reference.notificationReceivers` | Получатели TG-уведомлений |

### 📋 Шаблоны автоматизаций (3) — NEW!
| Tool | Описание |
|------|----------|
| `automations.templates.list` | Каталог шаблонов (фильтр по платформе и группе) |
| `automations.templates.get` | Детали шаблона с полной схемой |
| `automations.templates.apply` | Применить шаблон к боту (создаёт готовую автоматизацию) |

### 💬 Чаты (5)
| Tool | Описание |
|------|----------|
| `chats.list` | Список чатов |
| `chats.get` | Детали чата |
| `chats.messages` | История сообщений |
| `chats.sendMessage` | Отправить сообщение (чат должен быть open) |
| `chats.open` | Переоткрыть закрытый чат (оператор берёт управление от AI) |
| `chats.close` | Закрыть чат (вернуть AI/автоматизации) |

### 📨 Рассылки (8)
| Tool | Описание |
|------|----------|
| `mailings.list` | Список рассылок |
| `mailings.get` | Детали рассылки |
| `mailings.analytics` | **NEW** Аналитика рассылки |
| `mailings.create` | Создать рассылку |
| `mailings.update` | Обновить |
| `mailings.delete` | Удалить |
| `mailings.cancel` | Отменить |
| `mailings.copy` | Копировать |
| `mailings.predictClients` | Прогноз: кол-во получателей и время |

### 🧠 AI-агент (7)
| Tool | Описание |
|------|----------|
| `aiAgent.status` | Статус и настройки AI-агента |
| `aiAgent.analytics` | Аналитика: сообщения, диалоги, минуты |
| `aiAgent.publish` | Активировать |
| `aiAgent.unpublish` | Деактивировать |
| `aiAgent.updateSettings` | Настройки: DM/комменты, кнопки, задержка |
| `aiAgent.updateGlobalRules` | Глобальные правила |
| `aiAgent.testQuestion` | Тестовый вопрос |

### 📚 База знаний AI (7)
| Tool | Описание |
|------|----------|
| `aiAgent.knowledgeBase.list` | Список Q&A (поиск, сортировка) |
| `aiAgent.knowledgeBase.get` | Одна запись |
| `aiAgent.knowledgeBase.questions` | Неотвеченные вопросы |
| `aiAgent.knowledgeBase.add` | Добавить Q&A |
| `aiAgent.knowledgeBase.addAnswer` | Ответить на вопрос |
| `aiAgent.knowledgeBase.update` | Обновить запись |
| `aiAgent.knowledgeBase.bulkUpdate` | Массовое обновление (до 50) |
| `aiAgent.knowledgeBase.delete` | Удалить |
| `aiAgent.knowledgeBase.bulkDelete` | Массовое удаление (до 50) |

### 📊 Virale — аналитика контента (5)
| Tool | Описание |
|------|----------|
| `virale.accounts.list` | Список аккаунтов |
| `virale.accounts.get` | Детали аккаунта |
| `virale.accounts.add` | Добавить аккаунт (IG/TikTok/YT URL) |
| `virale.dashboard` | Дашборд: статы, тренды, анализ |
| `virale.recommendations` | Рекомендации роста |
| `virale.videos.list` | Список видео (сортировка: views/date/engagement) |
| `virale.videos.get` | Детали видео с анализом |

### 🏷 Теги (5)
| Tool | Описание |
|------|----------|
| `tags.list` | Список тегов |
| `tags.get` | Детали тега |
| `tags.create` | Создать тег (name, color hex) |
| `tags.update` | Обновить |
| `tags.delete` | Удалить |

### 📐 Переменные (5)
| Tool | Описание |
|------|----------|
| `variables.list` | Список переменных |
| `variables.get` | Детали переменной |
| `variables.create` | Создать переменную |
| `variables.update` | Обновить |
| `variables.delete` | Удалить |

## Построение сложной автоматизации (NEW!)

Раньше сложные воронки (условия, задержки, ветвление) можно было строить только в UI. **Теперь всё доступно через API:**

### Пошаговый алгоритм:

```
1. automations.create → получить automationId
2. automations.triggers.set → установить триггеры и ключевые слова
3. automations.steps.create → создать шаги
4. automations.steps.setStart → установить первый шаг
5. automations.messages.create → создать блоки (message/condition/action)
6. automations.inlineButtons.create → кнопки на сообщениях
7. automations.inlineButtons.setup → настроить тип (url/payment/normal)
8. automations.actions.setup → действия (теги, задержки, HTTP)
9. automations.conditions.setup → условия (has_tags, check_variable)
10. automations.messages.connect / buttons.connect → соединить блоки
11. automations.changeStatus → активировать ("active")
```

### Типы триггеров по платформе:

**Instagram:** messageContains, messageEquals, messageAnyValue, commentContains, commentEquals, commentAnyValue, storyReaction, storyMention, storyReply, liveCommentContains, liveCommentEquals, liveCommentAnyValue
**Telegram:** messageContains, messageEquals, messageAnyValue
**TikTok:** messageContains, messageEquals, messageAnyValue
**AI (требует AI-пакет):** messageContainsRecognition

### quickSetup шаблоны:

**base:** welcome → кнопка → сообщение с ссылкой
- Опции: reminderMessage, additionalMaterialMessage (с задержкой), autoAnswers (IG), photoId

**checkSubscription:** welcome → проверка подписки → подписан/не подписан
- Требует: telegramChannels (из triggers.listTelegramChannels)

### Пример: воронка с условием и тегами

```bash
# 1. Создать автоматизацию
./scripts/mcp_client.sh call automations.create '{"botId":"<YOUR_BOT_ID>","name":"Воронка с условием"}'

# 2. Получить справочник действий
./scripts/mcp_client.sh call automations.reference.actions '{}'

# 3. Установить триггер
./scripts/mcp_client.sh call automations.triggers.set '{"automationId":"...","triggerTypes":["messageContains"],"startMessages":["прайс","цена"]}'

# 4. Создать шаг
./scripts/mcp_client.sh call automations.steps.create '{"automationId":"...","name":"Основной"}'

# 5. Создать сообщение
./scripts/mcp_client.sh call automations.messages.create '{"stepId":"...","actionType":"message","text":"Привет! Выбери тариф:"}'

# 6. Добавить кнопки
./scripts/mcp_client.sh call automations.inlineButtons.create '{"messageId":"...","text":"Базовый"}'
./scripts/mcp_client.sh call automations.inlineButtons.create '{"messageId":"...","text":"Премиум"}'

# 7. Создать условие
./scripts/mcp_client.sh call automations.messages.create '{"stepId":"...","actionType":"condition"}'

# 8. Настроить условие (проверка тега)
./scripts/mcp_client.sh call automations.conditions.setup '{"conditionButtonId":"...","subConditions":[{"conditionLabel":"has_tags","tagIds":["..."]}]}'

# 9. Добавить действие (поставить тег)
./scripts/mcp_client.sh call automations.actions.setup '{"messageId":"...","subActions":[{"actionLabel":"add_tag","tagIds":["..."]}]}'

# 10. Соединить блоки
./scripts/mcp_client.sh call automations.messages.connect '{"triggerMessageId":"...","sendMessageId":"..."}'

# 11. Активировать
./scripts/mcp_client.sh call automations.changeStatus '{"automationId":"...","status":"active"}'
```

### Шаблоны из каталога

```bash
# Список шаблонов для Telegram
./scripts/mcp_client.sh call automations.templates.list '{"platforms":["telegram"]}'

# Применить шаблон к боту
./scripts/mcp_client.sh call automations.templates.apply '{"botId":"...","templateId":"..."}'
```

## Ссылки

- Платформа: https://chatplace.io
- Документация: https://help.chatplace.io/en/collections/3744239-русский
- MCP endpoint: https://mcp.chatplace.io/mcp
