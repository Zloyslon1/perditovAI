#!/usr/bin/env bash
# ChatPlace MCP Client — обёртка для JSON-RPC вызовов к mcp.chatplace.io
# Использование:
#   ./mcp_client.sh init              — инициализация сессии
#   ./mcp_client.sh tools             — список доступных инструментов
#   ./mcp_client.sh call <tool> <args> — вызов инструмента (args = JSON)

set -euo pipefail

MCP_URL="https://mcp.chatplace.io/mcp"
API_KEY="${CHATPLACE_API_KEY:-}"
SESSION_FILE="/tmp/chatplace_mcp_session.json"

if [[ -z "$API_KEY" ]]; then
  echo "ERROR: CHATPLACE_API_KEY не установлен"
  echo "Установи: export CHATPLACE_API_KEY='ваш_ключ'"
  exit 1
fi

# Извлечь session-id из заголовков ответа
extract_session_id() {
  local headers_file="$1"
  grep -i 'mcp-session-id' "$headers_file" 2>/dev/null | sed 's/.*: //' | tr -d '\r\n' || true
}

# Загрузить session-id если есть
load_session_id() {
  if [[ -f "$SESSION_FILE" ]]; then
    cat "$SESSION_FILE" 2>/dev/null || true
  fi
}

# Сохранить session-id
save_session_id() {
  echo "$1" > "$SESSION_FILE"
}

# Основной запрос к MCP
mcp_request() {
  local body="$1"
  local session_id
  session_id=$(load_session_id)
  
  local headers_file
  headers_file=$(mktemp)
  
  local curl_args=(
    -s
    -X POST "$MCP_URL"
    -H "Content-Type: application/json"
    -H "Accept: application/json"
    -H "Authorization: Bearer $API_KEY"
    -D "$headers_file"
    -d "$body"
  )
  
  # Добавить session-id если есть
  if [[ -n "$session_id" ]]; then
    curl_args+=(-H "Mcp-Session-Id: $session_id")
  fi
  
  local response
  response=$(curl "${curl_args[@]}" 2>&1)
  
  # Сохранить session-id из ответа
  local new_session_id
  new_session_id=$(extract_session_id "$headers_file")
  if [[ -n "$new_session_id" ]]; then
    save_session_id "$new_session_id"
  fi
  
  rm -f "$headers_file"
  echo "$response"
}

# Инициализация MCP сессии
cmd_init() {
  local body
  body=$(cat <<'EOF'
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "initialize",
  "params": {
    "protocolVersion": "2024-11-05",
    "capabilities": {},
    "clientInfo": {
      "name": "openclaw-chatplace",
      "version": "1.0.0"
    }
  }
}
EOF
)
  echo "=== Инициализация MCP сессии ==="
  local result
  result=$(mcp_request "$body")
  echo "$result" | python3 -m json.tool 2>/dev/null || echo "$result"
  
  # Отправляем initialized notification
  local notif='{"jsonrpc":"2.0","method":"notifications/initialized"}'
  mcp_request "$notif" > /dev/null 2>&1
  echo ""
  echo "✅ Сессия инициализирована"
}

# Список инструментов
cmd_tools() {
  # Убедиться что сессия инициализирована
  if [[ ! -f "$SESSION_FILE" ]]; then
    cmd_init > /dev/null 2>&1
  fi
  
  local body='{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}'
  echo "=== Доступные инструменты ChatPlace ==="
  local result
  result=$(mcp_request "$body")
  echo "$result" | python3 -m json.tool 2>/dev/null || echo "$result"
}

# Вызов инструмента
EMPTY_JSON='{}'
cmd_call() {
  local tool_name="${1:-}"
  local tool_args="${2:-$EMPTY_JSON}"
  
  if [[ -z "$tool_name" ]]; then
    echo "ERROR: укажи имя инструмента"
    echo "Использование: $0 call <tool_name> '{\"key\":\"value\"}'"
    exit 1
  fi
  
  # Убедиться что сессия инициализирована
  if [[ ! -f "$SESSION_FILE" ]]; then
    cmd_init > /dev/null 2>&1
  fi
  
  local body
  body=$(python3 -c "
import json
import sys
tool_name = sys.argv[1]
tool_args = sys.argv[2]
print(json.dumps({
    'jsonrpc': '2.0',
    'id': 3,
    'method': 'tools/call',
    'params': {
        'name': tool_name,
        'arguments': json.loads(tool_args)
    }
}))
" "$tool_name" "$tool_args")
  
  echo "=== Вызов: $tool_name ==="
  local result
  result=$(mcp_request "$body")
  echo "$result" | python3 -m json.tool 2>/dev/null || echo "$result"
}

# Ресурсы
cmd_resources() {
  if [[ ! -f "$SESSION_FILE" ]]; then
    cmd_init > /dev/null 2>&1
  fi
  
  local body='{"jsonrpc":"2.0","id":4,"method":"resources/list","params":{}}'
  echo "=== Ресурсы ChatPlace ==="
  local result
  result=$(mcp_request "$body")
  echo "$result" | python3 -m json.tool 2>/dev/null || echo "$result"
}

# Промпты
cmd_prompts() {
  if [[ ! -f "$SESSION_FILE" ]]; then
    cmd_init > /dev/null 2>&1
  fi
  
  local body='{"jsonrpc":"2.0","id":5,"method":"prompts/list","params":{}}'
  echo "=== Промпты ChatPlace ==="
  local result
  result=$(mcp_request "$body")
  echo "$result" | python3 -m json.tool 2>/dev/null || echo "$result"
}

# Сброс сессии
cmd_reset() {
  rm -f "$SESSION_FILE"
  echo "✅ Сессия сброшена"
}

# Маршрутизация команд
case "${1:-help}" in
  init)     cmd_init ;;
  tools)    cmd_tools ;;
  call)     cmd_call "${2:-}" "${3:-$EMPTY_JSON}" ;;
  resources) cmd_resources ;;
  prompts)  cmd_prompts ;;
  reset)    cmd_reset ;;
  help|*)
    echo "ChatPlace MCP Client"
    echo ""
    echo "Команды:"
    echo "  init       — инициализация MCP сессии"
    echo "  tools      — список доступных инструментов"
    echo "  call <tool> '{args}' — вызов инструмента"
    echo "  resources  — список ресурсов"
    echo "  prompts    — список промптов"
    echo "  reset      — сброс сессии"
    echo ""
    echo "Переменные окружения:"
    echo "  CHATPLACE_API_KEY — API ключ (обязательно)"
    ;;
esac
