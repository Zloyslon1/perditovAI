---
name: reel-maker
description: "Universal short-form video pipeline (Reels/Shorts/TikTok) with briefing. Use when asked to create a video reel, short video, or anything combining voiceover + animated scenes + captions. Triggers on: 'сделай рилс', 'создай видео', 'рилс', 'reels', 'shorts', 'сделай ролик', 'видео с субтитрами', 'reel maker'."
---

# Reel Maker

Universal pipeline: **briefing → scenes → voice → animation → captions → final mix**.

Works with ANY visual style — pixel art, cinematic, anime, 3D, photorealistic, etc.

## Briefing Flow

Before starting, collect these from the user (ask what's missing):

### 1. Script (REQUIRED)
- Full text of the video, split into sentences
- Language: RU / EN
- If not provided — ask user to write or provide a topic to generate

### 2. Visual Style (REQUIRED)
Choose or describe:
| Preset | Description |
|--------|-------------|
| `pixel` | 16-bit pixel art, lo-fi aesthetic, dark moody palette |
| `cinematic` | Photorealistic, dramatic lighting, film grain |
| `anime` | Anime/manga style, vibrant colors |
| `3d` | 3D rendered, stylized characters |
| `minimal` | Clean, flat design, pastel colors |
| `custom` | User describes their own style |

### 3. Character (OPTIONAL)
- Description: hair, beard, clothing, vibe
- Reference photo path (for image-to-video with Veo 3)
- Or: no character (abstract scenes)

### 4. Voice (OPTIONAL, defaults exist)
- Language: `ru` / `en`
- ElevenLabs voice ID (or use default from env)
- Speed multiplier (default: 1.0)
- Or: no voice (music only)

### 5. Music (OPTIONAL)
- Path to music file
- Or: no music (voice only)
- Voice/music balance (default: voice 200%, music 35%)

### 6. Caption Style (OPTIONAL, defaults exist)
| Preset | Description |
|--------|-------------|
| `word-pop` | Word-by-word, center screen, fade+slide animation (DEFAULT) |
| `subtitle` | Bottom subtitle bar, 2-3 words at a time |
| `karaoke` | Full sentence with highlighted current word |
| `none` | No captions |

Caption color options:
- `white` — white text, dark shadow (default)
- `gold_first` — first sentence golden, rest white
- `custom` — user specifies RGB

### 7. Format (OPTIONAL)
- Resolution: 1080x1920 (default, 9:16 vertical)
- FPS: 30 (default)
- Duration target: auto from voice, or specify seconds

---

## After Briefing — Save Config

Save all briefing answers to a JSON config file:

```bash
# Save to project directory
cat > ${PROJECT_DIR}/reel_config.json << 'EOF'
{
  "script": {
    "sentences": [
      {"text": "First sentence.", "style": "serif_gold"},
      {"text": "Second sentence.", "style": "sans_white"},
      ...
    ],
    "language": "ru"
  },
  "visual": {
    "preset": "pixel",
    "style_prefix": "16-bit pixel art, lo-fi aesthetic, vertical 9:16.",
    "image_backend": "nbp",
    "scene_prompts": []
  },
  "character": {
    "description": "Young man with curly hair and beard",
    "reference_photo": null
  },
  "voice": {
    "enabled": true,
    "language": "ru",
    "voice_id": null,
    "speed": 1.0
  },
  "music": {
    "enabled": true,
    "track_path": "/path/to/music.mp3",
    "voice_volume": 2.0,
    "music_volume": 0.35
  },
  "captions": {
    "preset": "word-pop",
    "color": [255, 255, 255],
    "first_sentence_color": [220, 180, 80],
    "backdrop": true,
    "font_size_base": 80,
    "uppercase_range": [5, 8]
  },
  "format": {
    "width": 1080,
    "height": 1920,
    "fps": 30
  }
}
EOF
```

---

## Pipeline Execution

Once config is saved, run steps in order:

### Step 1: Generate Voice (if enabled)
```bash
python3 scripts/generate_voice.py ${PROJECT_DIR}/reel_config.json
# Output: ${PROJECT_DIR}/voice_full.mp3 + per-sentence files
```

### Step 2: Get Word Timestamps
```bash
python3 scripts/get_timestamps.py ${PROJECT_DIR}/reel_config.json
# Output: ${PROJECT_DIR}/timestamps.json
```

### Step 3: Generate Scene Images
```bash
python3 scripts/generate_scenes.py ${PROJECT_DIR}/reel_config.json
# Output: ${PROJECT_DIR}/scene_01.png ... scene_N.png
# Backends: NBP (default) / Sora (gpt-image-1) / Gemini Pro
# Set visual.image_backend in config: "nbp", "sora", or "gemini"
```

### Step 4: Animate Scenes (Veo)
```bash
python3 scripts/animate_scenes.py ${PROJECT_DIR}/reel_config.json
# Output: ${PROJECT_DIR}/clip_01.mp4 ... clip_N.mp4 + background.mp4
```

### Step 5: Render Final Video
```bash
python3 scripts/render_final.py ${PROJECT_DIR}/reel_config.json
# Output: ${PROJECT_DIR}/reel_final.mp4
```

---

## Environment Variables

```bash
# Required
GEMINI_API_KEY=...          # Google AI Studio (for NBP/Gemini image gen + Veo)
GROQ_API_KEY=...            # Groq (for Whisper timestamps)
ELEVENLABS_API_KEY=...      # ElevenLabs (for voice)

# Optional
OPENAI_API_KEY=...          # OpenAI (for Sora / gpt-image-1)
ELEVENLABS_VOICE_ID_RU=...  # Default Russian voice
ELEVENLABS_VOICE_ID_EN=...  # Default English voice
LAOZHANG_API_KEY=...        # LaoZhang proxy for Veo
```

---

## Visual Style Prompt Templates

When generating scene prompts from sentences, prepend the style prefix:

| Preset | Prefix |
|--------|--------|
| `pixel` | `16-bit pixel art, lo-fi aesthetic, vertical 9:16.` |
| `cinematic` | `Cinematic photorealistic, dramatic lighting, film grain, vertical 9:16.` |
| `anime` | `Anime style, vibrant colors, detailed background, vertical 9:16.` |
| `3d` | `3D rendered, stylized, soft lighting, vertical 9:16.` |
| `minimal` | `Minimal flat design, pastel colors, clean composition, vertical 9:16.` |

For each sentence, generate a scene description prompt:
1. Take the sentence meaning
2. Prepend visual style prefix
3. Add character description if provided
4. Add "No text." at the end
5. Translate to English (Veo/Imagen work better in English)

---

## Critical Rules

- **Veo 2 + image → BLOCKED in EU** (use text-only mode or Veo 3)
- **Veo text-only → works** (~$2.5 for 12 clips)
- **PIL frames**: NEVER collect in list → pipe each frame to ffmpeg stdin
- **macOS fonts**: use `/Library/Fonts/` or `/System/Library/Fonts/`
- **Veo durationSeconds**: 6 (stable), min=5, max=8

## Cost Estimates

| Component | ~Price |
|-----------|--------|
| Scene images (NBP/Sora/Gemini) × 12 | ~$0.50-2.00 |
| Veo 2 text-only × 12 clips | ~$2.50 |
| ElevenLabs voice | ~$0.05 |
| Groq Whisper | $0.00 |
| **Total** | **~$3** |

## Fallback: Ken Burns

If Veo fails for a scene, fallback to Ken Burns (slow zoom) from static image:
```bash
ffmpeg -y -loop 1 -i scene.png -t ${DURATION} \
  -vf "scale=1080:1920,zoompan=z='min(zoom+0.0015,1.1)':d=1:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)'" \
  -r 30 -c:v libx264 -preset fast -crf 20 -pix_fmt yuv420p -an output.mp4
```
