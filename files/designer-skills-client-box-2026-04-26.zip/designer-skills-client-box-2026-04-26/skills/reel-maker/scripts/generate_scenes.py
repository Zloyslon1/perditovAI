"""
Step 3: Generate scene images.
Usage: python3 generate_scenes.py <config.json>
Output: scene_01.png ... scene_N.png in project dir

Image generation backends (config.visual.image_backend):
- "nbp" (default) — Nano Banana Pro via uv, best for stylized
- "gemini" — Gemini 2.5 Pro native image generation
- "sora" — OpenAI Sora (gpt-image-1), best photorealistic quality

Fallback chain: selected backend → next in list → next
"""
import json, os, sys, subprocess, base64, requests, glob

STYLE_PREFIXES = {
    "pixel": "16-bit pixel art, lo-fi aesthetic, vertical 9:16.",
    "cinematic": "Cinematic photorealistic, dramatic lighting, film grain, vertical 9:16.",
    "anime": "Anime style, vibrant colors, detailed background, vertical 9:16.",
    "3d": "3D rendered, stylized, soft lighting, vertical 9:16.",
    "minimal": "Minimal flat design, pastel colors, clean composition, vertical 9:16.",
}

# Known NBP script locations
NBP_PATHS = [
    "/opt/homebrew/lib/node_modules/openclaw/skills/nano-banana-pro/scripts/generate_image.py",
    "/usr/lib/node_modules/openclaw/skills/nano-banana-pro/scripts/generate_image.py",
    os.path.expanduser("~/.openclaw/skills/nano-banana-pro/scripts/generate_image.py"),
]


def find_nbp_script():
    for p in NBP_PATHS:
        if os.path.exists(p):
            return p
    return None


def generate_scene_prompt(sentence_text, style_prefix, character_desc):
    """Build a scene prompt from sentence meaning + style + character."""
    parts = [style_prefix]
    if character_desc:
        parts.append(character_desc)
    parts.append(f"Scene depicting: {sentence_text}")
    parts.append("No text.")
    return " ".join(parts)


def generate_via_nbp(prompt, out_path, api_key, ref_photo=None):
    """Generate image via Nano Banana Pro (best quality)."""
    nbp_script = find_nbp_script()
    if not nbp_script:
        return False

    cmd = [
        "uv", "run", nbp_script,
        "--api-key", api_key,
        "--resolution", "1K",
        "--aspect-ratio", "9:16",
        "--filename", out_path,
        "--prompt", prompt,
    ]
    if ref_photo and os.path.exists(ref_photo):
        cmd.extend(["-i", ref_photo])

    result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    return os.path.exists(out_path) and os.path.getsize(out_path) > 5000


def generate_via_sora(prompt, out_path):
    """Generate image via OpenAI Sora (gpt-image-1)."""
    openai_key = os.environ.get("OPENAI_API_KEY", "")
    if not openai_key:
        print("    OPENAI_API_KEY not set, skipping Sora")
        return False

    resp = requests.post(
        "https://api.openai.com/v1/images/generations",
        headers={
            "Authorization": f"Bearer {openai_key}",
            "Content-Type": "application/json",
        },
        json={
            "model": "gpt-image-1",
            "prompt": prompt,
            "n": 1,
            "size": "1024x1792",  # 9:16 vertical
            "quality": "high",
        },
        timeout=120,
    )
    if resp.status_code != 200:
        print(f"    Sora error: {resp.status_code} {resp.text[:200]}")
        return False

    data = resp.json()
    items = data.get("data", [])
    if not items:
        return False

    # gpt-image-1 returns b64_json
    b64 = items[0].get("b64_json")
    if b64:
        img_bytes = base64.b64decode(b64)
        with open(out_path, "wb") as f:
            f.write(img_bytes)
        return os.path.getsize(out_path) > 5000

    # or url
    url = items[0].get("url")
    if url:
        img_resp = requests.get(url, timeout=60)
        if img_resp.status_code == 200:
            with open(out_path, "wb") as f:
                f.write(img_resp.content)
            return os.path.getsize(out_path) > 5000

    return False


def generate_via_gemini(prompt, out_path, api_key):
    """Generate image via Gemini 2.5 Pro native image generation (fallback)."""
    resp = requests.post(
        f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-pro-preview-06-05:generateContent?key={api_key}",
        headers={"Content-Type": "application/json"},
        json={
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "responseModalities": ["image", "text"],
                "imageDimensions": {"aspectRatio": "9:16"},
            },
        },
        timeout=120,
    )
    if resp.status_code != 200:
        print(f"    Gemini error: {resp.status_code} {resp.text[:200]}")
        return False

    data = resp.json()
    for cand in data.get("candidates", []):
        for part in cand.get("content", {}).get("parts", []):
            if "inlineData" in part:
                img_bytes = base64.b64decode(part["inlineData"]["data"])
                with open(out_path, "wb") as f:
                    f.write(img_bytes)
                return os.path.getsize(out_path) > 5000
    return False


def main():
    config_path = sys.argv[1]
    with open(config_path) as f:
        config = json.load(f)

    project_dir = os.path.dirname(os.path.abspath(config_path))
    visual = config.get("visual", {})
    character = config.get("character", {})
    sentences = config["script"]["sentences"]

    api_key = os.environ.get("GEMINI_API_KEY", "")
    if not api_key:
        print("ERROR: GEMINI_API_KEY not set")
        sys.exit(1)

    # Determine style prefix
    preset = visual.get("preset", "pixel")
    style_prefix = visual.get("style_prefix") or STYLE_PREFIXES.get(preset, STYLE_PREFIXES["pixel"])
    char_desc = character.get("description", "")
    ref_photo = character.get("reference_photo")

    # Use pre-built prompts if provided, otherwise generate
    scene_prompts = visual.get("scene_prompts", [])

    # Backend selection: config or auto-detect
    image_backend = visual.get("image_backend", "nbp")  # "nbp", "gemini", "sora"
    nbp_available = find_nbp_script() is not None

    backend_order = {
        "nbp": ["nbp", "gemini", "sora"],
        "gemini": ["gemini", "nbp", "sora"],
        "sora": ["sora", "nbp", "gemini"],
    }.get(image_backend, ["nbp", "gemini", "sora"])

    print(f"Backend: {image_backend} (fallback chain: {' → '.join(backend_order)})")

    for i, sent in enumerate(sentences):
        out_path = os.path.join(project_dir, f"scene_{i + 1:02d}.png")
        if os.path.exists(out_path) and os.path.getsize(out_path) > 5000:
            print(f"Scene {i + 1}: exists, skip")
            continue

        if i < len(scene_prompts) and scene_prompts[i]:
            prompt = scene_prompts[i]
        else:
            prompt = generate_scene_prompt(sent["text"], style_prefix, char_desc)

        print(f"Scene {i + 1}: generating...")
        print(f"  Prompt: {prompt[:100]}...")

        generated = False
        for backend in backend_order:
            if backend == "nbp" and nbp_available:
                ok = generate_via_nbp(prompt, out_path, api_key, ref_photo)
                if ok:
                    print(f"  ✅ NBP: {os.path.getsize(out_path) // 1024}KB")
                    generated = True
                    break
                print(f"  ⚠️ NBP failed, next...")
            elif backend == "sora":
                ok = generate_via_sora(prompt, out_path)
                if ok:
                    print(f"  ✅ Sora: {os.path.getsize(out_path) // 1024}KB")
                    generated = True
                    break
                print(f"  ⚠️ Sora failed, next...")
            elif backend == "gemini":
                ok = generate_via_gemini(prompt, out_path, api_key)
                if ok:
                    print(f"  ✅ Gemini Pro: {os.path.getsize(out_path) // 1024}KB")
                    generated = True
                    break
                print(f"  ⚠️ Gemini failed, next...")

        if not generated:
            print(f"  ❌ Scene {i + 1}: FAILED (all backends)")

    # Summary
    files = sorted(glob.glob(os.path.join(project_dir, "scene_*.png")))
    print(f"\n=== {len(files)}/{len(sentences)} scenes generated ===")


if __name__ == "__main__":
    main()
