"""
Step 2: Get word-level timestamps from voice files via Groq Whisper.
Usage: python3 get_timestamps.py <config.json>
Output: timestamps.json in project dir
"""
import json, os, sys, requests

def main():
    config_path = sys.argv[1]
    with open(config_path) as f:
        config = json.load(f)

    project_dir = os.path.dirname(os.path.abspath(config_path))
    sentences = config["script"]["sentences"]
    lang = config["script"].get("language", "ru")

    groq_key = os.environ.get("GROQ_API_KEY", "")
    if not groq_key:
        print("ERROR: GROQ_API_KEY not set")
        sys.exit(1)

    # Load durations
    dur_path = os.path.join(project_dir, "durations.json")
    if os.path.exists(dur_path):
        with open(dur_path) as f:
            durations = json.load(f)
    else:
        print("WARNING: durations.json not found, using estimate 2.5s per sentence")
        durations = [2.5] * len(sentences)

    global_words = []
    time_offset = 0.0
    GAP = 0.08

    for i, sent in enumerate(sentences):
        text = sent["text"]
        style = sent.get("style", "sans_white")
        dur = durations[i] if i < len(durations) else 2.5
        voice_file = os.path.join(project_dir, f"voice_s{i:02d}.mp3")

        if not os.path.exists(voice_file):
            # Fallback: distribute words evenly
            words = text.split()
            tpw = dur / max(1, len(words))
            for wi, w in enumerate(words):
                global_words.append({
                    "word": w, "seg": i, "style": style,
                    "start": round(time_offset + wi * tpw, 4),
                    "end": round(time_offset + (wi + 0.85) * tpw, 4),
                })
            time_offset += dur + GAP
            continue

        # Whisper word timestamps
        with open(voice_file, "rb") as f:
            resp = requests.post(
                "https://api.groq.com/openai/v1/audio/transcriptions",
                headers={"Authorization": f"Bearer {groq_key}"},
                files={"file": ("audio.mp3", f, "audio/mpeg")},
                data={
                    "model": "whisper-large-v3",
                    "language": lang,
                    "response_format": "verbose_json",
                    "timestamp_granularities[]": "word",
                },
                timeout=30,
            )

        timed = resp.json().get("words", [])
        sentence_words = text.split()

        if timed:
            for wi, tw in enumerate(timed):
                orig = sentence_words[wi] if wi < len(sentence_words) else tw["word"]
                global_words.append({
                    "word": orig, "seg": i, "style": style,
                    "start": round(time_offset + tw["start"], 4),
                    "end": round(time_offset + tw["end"], 4),
                })
        else:
            tpw = dur / max(1, len(sentence_words))
            for wi, w in enumerate(sentence_words):
                global_words.append({
                    "word": w, "seg": i, "style": style,
                    "start": round(time_offset + wi * tpw, 4),
                    "end": round(time_offset + (wi + 0.85) * tpw, 4),
                })

        time_offset += dur + GAP
        print(f"  Sentence {i}: {len(timed)} words timestamped")

    out_path = os.path.join(project_dir, "timestamps.json")
    result = {
        "words": global_words,
        "total_duration": round(time_offset, 4),
        "sentence_count": len(sentences),
    }
    with open(out_path, "w") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    print(f"\n✅ {len(global_words)} words, {time_offset:.2f}s → {out_path}")


if __name__ == "__main__":
    main()
