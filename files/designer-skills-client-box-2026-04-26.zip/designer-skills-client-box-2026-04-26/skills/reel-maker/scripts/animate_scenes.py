"""
Step 4: Animate scene images via Veo 2/3 (or Ken Burns fallback).
Usage: python3 animate_scenes.py <config.json>
Output: clip_01.mp4 ... clip_N.mp4 + background.mp4 in project dir
"""
import json, os, sys, time, subprocess, requests, base64

STYLE_PREFIXES = {
    "pixel": "Pixel art lo-fi animation 9:16.",
    "cinematic": "Cinematic photorealistic animation 9:16, dramatic lighting, subtle camera movement.",
    "anime": "Anime style animation 9:16, vibrant colors, fluid motion.",
    "3d": "3D rendered animation 9:16, soft lighting, gentle movement.",
    "minimal": "Minimal flat animation 9:16, smooth transitions, pastel colors.",
}


def submit_veo(prompt, api_key, proxy=None, model="veo-2.0-generate-001"):
    payload = {
        "instances": [{"prompt": prompt}],
        "parameters": {"aspectRatio": "9:16", "durationSeconds": 6, "sampleCount": 1},
    }
    proxies = {"https": proxy, "http": proxy} if proxy else None
    r = requests.post(
        f"https://generativelanguage.googleapis.com/v1beta/models/{model}:predictLongRunning",
        headers={"x-goog-api-key": api_key, "Content-Type": "application/json"},
        json=payload,
        proxies=proxies,
        timeout=30,
    )
    if r.status_code != 200:
        raise Exception(f"Submit {r.status_code}: {r.text[:300]}")
    return r.json()["name"]


def poll_veo(op_name, api_key, proxy=None, timeout=600):
    start = time.time()
    proxies = {"https": proxy, "http": proxy} if proxy else None
    while time.time() - start < timeout:
        r = requests.get(
            f"https://generativelanguage.googleapis.com/v1beta/{op_name}",
            headers={"x-goog-api-key": api_key},
            proxies=proxies,
            timeout=30,
        )
        data = r.json()
        if data.get("done"):
            resp = data.get("response", {})
            samples = resp.get("generateVideoResponse", {}).get("generatedSamples", [])
            if samples:
                uri = samples[0].get("video", {}).get("uri")
                if uri:
                    dl_url = uri + (f"&key={api_key}" if "?" in uri else f"?key={api_key}")
                    dr = requests.get(dl_url, proxies=proxies, timeout=120)
                    if dr.status_code == 200 and len(dr.content) > 10000:
                        return dr.content
            # Try inline data
            for cand in resp.get("candidates", []):
                for part in cand.get("content", {}).get("parts", []):
                    if "inline_data" in part:
                        return base64.b64decode(part["inline_data"]["data"])
            return None
        if "error" in data:
            raise Exception(f"Veo error: {data['error']}")
        elapsed = int(time.time() - start)
        print(f"    [{elapsed}s] waiting...")
        time.sleep(20)
    raise Exception("Veo timeout")


def ken_burns_fallback(image_path, duration, output_path):
    """Slow zoom fallback from static image."""
    subprocess.run([
        "ffmpeg", "-y", "-loop", "1", "-i", image_path,
        "-t", str(duration),
        "-vf", "scale=1080:1920,zoompan=z='min(zoom+0.0015,1.1)':d=1:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)'",
        "-r", "30", "-c:v", "libx264", "-preset", "fast", "-crf", "20",
        "-pix_fmt", "yuv420p", "-an", output_path,
    ], capture_output=True)


def main():
    config_path = sys.argv[1]
    with open(config_path) as f:
        config = json.load(f)

    project_dir = os.path.dirname(os.path.abspath(config_path))
    visual = config.get("visual", {})
    character = config.get("character", {})
    sentences = config["script"]["sentences"]

    api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("LAOZHANG_API_KEY", "")
    if not api_key:
        print("ERROR: GEMINI_API_KEY not set")
        sys.exit(1)

    # Load durations
    dur_path = os.path.join(project_dir, "durations.json")
    if os.path.exists(dur_path):
        with open(dur_path) as f:
            durations = json.load(f)
    else:
        durations = [3.0] * len(sentences)

    proxy = os.environ.get("VEO_PROXY")  # e.g. socks5://127.0.0.1:1081
    preset = visual.get("preset", "pixel")
    anim_prefix = visual.get("animation_prefix") or STYLE_PREFIXES.get(preset, STYLE_PREFIXES["pixel"])
    char_desc = character.get("description", "")
    scene_prompts = visual.get("scene_prompts", [])

    clips = []
    for i, sent in enumerate(sentences):
        num = i + 1
        clip_path = os.path.join(project_dir, f"clip_{num:02d}.mp4")
        duration = durations[i] if i < len(durations) else 3.0

        if os.path.exists(clip_path) and os.path.getsize(clip_path) > 50000:
            print(f"Clip {num}: exists ✅")
            clips.append(clip_path)
            continue

        # Build animation prompt
        if i < len(scene_prompts) and scene_prompts[i]:
            prompt = scene_prompts[i].replace("pixel art,", "pixel art animation,")
        else:
            prompt = f"{anim_prefix} {char_desc} Scene: {sent['text']}"

        try:
            print(f"Clip {num}: submitting to Veo...")
            op = submit_veo(prompt, api_key, proxy)
            print(f"Clip {num}: polling...")
            video_bytes = poll_veo(op, api_key, proxy)

            if video_bytes:
                raw = os.path.join(project_dir, f"raw_{num:02d}.mp4")
                with open(raw, "wb") as f:
                    f.write(video_bytes)
                subprocess.run([
                    "ffmpeg", "-y", "-i", raw, "-t", str(duration),
                    "-c:v", "libx264", "-preset", "fast", "-crf", "20",
                    "-pix_fmt", "yuv420p", "-vf", "scale=1080:1920", "-an", clip_path,
                ], capture_output=True)
                if os.path.exists(clip_path):
                    print(f"Clip {num}: ✅ {os.path.getsize(clip_path) // 1024}KB")
                    clips.append(clip_path)
                else:
                    raise Exception("ffmpeg trim failed")
            else:
                raise Exception("No video bytes from Veo")
        except Exception as e:
            print(f"Clip {num}: ❌ {e} → Ken Burns fallback")
            img = os.path.join(project_dir, f"scene_{num:02d}.png")
            if os.path.exists(img):
                ken_burns_fallback(img, duration, clip_path)
                clips.append(clip_path)
            else:
                print(f"  No image for fallback either!")

    # Concatenate all clips
    bg_path = os.path.join(project_dir, "background.mp4")
    concat_file = os.path.join(project_dir, "concat.txt")
    with open(concat_file, "w") as f:
        for c in clips:
            f.write(f"file '{c}'\n")

    subprocess.run([
        "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", concat_file,
        "-c:v", "libx264", "-preset", "fast", "-crf", "18", "-pix_fmt", "yuv420p", bg_path,
    ], capture_output=True)

    if os.path.exists(bg_path):
        print(f"\n✅ Background: {bg_path} ({os.path.getsize(bg_path) // 1024}KB)")
    else:
        print("ERROR: Failed to concat clips")


if __name__ == "__main__":
    main()
