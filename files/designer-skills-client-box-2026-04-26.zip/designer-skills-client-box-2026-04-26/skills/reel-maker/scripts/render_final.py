"""
Step 5: Render final video — background + word captions + voice + music.
Usage: python3 render_final.py <config.json>
Output: reel_final.mp4 in project dir
"""
import json, os, sys, math, subprocess
from PIL import Image, ImageDraw, ImageFont

# macOS font paths
FONT_PATHS = {
    "sans": [
        "/Library/Fonts/Arial Bold.ttf",
        "/System/Library/Fonts/Helvetica.ttc",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    ],
    "serif": [
        "/Library/Fonts/Georgia Bold.ttf",
        "/Library/Fonts/Times New Roman Bold.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSerifBold.ttf",
    ],
}


def find_font(style):
    key = "serif" if "serif" in style else "sans"
    for path in FONT_PATHS[key]:
        if os.path.exists(path):
            return path
    # Ultimate fallback
    for root in ["/Library/Fonts", "/System/Library/Fonts", "/usr/share/fonts"]:
        if os.path.isdir(root):
            for f in os.listdir(root):
                if f.endswith((".ttf", ".ttc")) and "bold" in f.lower():
                    return os.path.join(root, f)
    return None


def ease_out(t):
    return 1 - (1 - max(0, min(1, t))) ** 3


_font_cache = {}
def get_font(style, size):
    k = (style, size)
    if k not in _font_cache:
        path = find_font(style)
        if path:
            _font_cache[k] = ImageFont.truetype(path, size)
        else:
            _font_cache[k] = ImageFont.load_default()
    return _font_cache[k]


def get_active_word(frame, fps, words):
    t = frame / fps
    best = None
    for i, w in enumerate(words):
        if w["start"] <= t:
            best = i
        else:
            break
    return best


def main():
    config_path = sys.argv[1]
    with open(config_path) as f:
        config = json.load(f)

    project_dir = os.path.dirname(os.path.abspath(config_path))
    fmt = config.get("format", {})
    W = fmt.get("width", 1080)
    H = fmt.get("height", 1920)
    FPS = fmt.get("fps", 30)

    captions_cfg = config.get("captions", {})
    caption_preset = captions_cfg.get("preset", "word-pop")
    if caption_preset == "none":
        print("Captions disabled, rendering video without captions")

    color_main = tuple(captions_cfg.get("color", [255, 255, 255]))
    color_first = tuple(captions_cfg.get("first_sentence_color", color_main))
    use_backdrop = captions_cfg.get("backdrop", True)
    backdrop_style = captions_cfg.get("backdrop_style", "gradient")  # "gradient" or "solid"
    font_size_base = captions_cfg.get("font_size_base", 80)
    uppercase_range = captions_cfg.get("uppercase_range", [])

    music_cfg = config.get("music", {})
    voice_cfg = config.get("voice", {})

    # Load timestamps
    ts_path = os.path.join(project_dir, "timestamps.json")
    with open(ts_path) as f:
        ts_data = json.load(f)
    global_words = ts_data["words"]
    total_dur = ts_data["total_duration"]
    total_frames = int(math.ceil(total_dur * FPS)) + 15

    # Paths
    bg_video = os.path.join(project_dir, "background.mp4")
    voice_file = os.path.join(project_dir, "voice_full.mp3")
    music_file = music_cfg.get("track_path", "")
    voice_vol = music_cfg.get("voice_volume", 2.0)
    music_vol = music_cfg.get("music_volume", 0.35)

    if not os.path.exists(bg_video):
        print(f"ERROR: background.mp4 not found at {bg_video}")
        sys.exit(1)

    print(f"Rendering: {len(global_words)} words, {total_dur:.1f}s, {total_frames} frames")
    print(f"Format: {W}x{H} @ {FPS}fps")

    # Extract background frames
    extract = subprocess.Popen([
        "ffmpeg", "-y", "-i", bg_video,
        "-t", str(total_dur + 1),
        "-vf", f"scale={W}:{H},fps={FPS}",
        "-f", "rawvideo", "-pix_fmt", "rgb24", "pipe:1",
    ], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)

    raw_video = os.path.join(project_dir, "composite_raw.mp4")
    encode = subprocess.Popen([
        "ffmpeg", "-y",
        "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
        "-c:v", "libx264", "-preset", "fast", "-crf", "18", "-pix_fmt", "yuv420p",
        raw_video,
    ], stdin=subprocess.PIPE, stderr=subprocess.DEVNULL)

    cx = W // 2
    frame_size = W * H * 3

    for frame in range(total_frames):
        raw_bytes = b""
        while len(raw_bytes) < frame_size:
            chunk = extract.stdout.read(frame_size - len(raw_bytes))
            if not chunk:
                raw_bytes = bytes(frame_size)
                break
            raw_bytes += chunk

        img = Image.frombytes("RGB", (W, H), raw_bytes)

        if caption_preset != "none":
            wi = get_active_word(frame, FPS, global_words)
            if wi is not None and wi < len(global_words):
                wd = global_words[wi]
                seg_idx = wd["seg"]
                style = wd.get("style", "sans_white")
                word_text = wd["word"]

                # Uppercase
                is_caps = "caps" in style or (uppercase_range and uppercase_range[0] <= seg_idx <= uppercase_range[1])
                if is_caps:
                    word_text = word_text.upper()

                # Color
                color = color_first if seg_idx == 0 and color_first != color_main else color_main
                if "brown" in style or "gold" in style:
                    color = color_first

                # Font size (adaptive)
                l = len(word_text)
                size_mult = font_size_base / 80.0
                base_size = int((118 if l <= 5 else 98 if l <= 8 else 80 if l <= 13 else 64 if l <= 18 else 52) * size_mult)
                if is_caps:
                    base_size = int(base_size * 0.80)
                if "serif" in style:
                    base_size = int(base_size * 0.90)

                font_main = get_font(style, base_size)
                t = frame / FPS
                word_age = t - wd["start"]
                fade = ease_out(min(1.0, word_age / 0.08))
                alpha = int(fade * 255)
                slide_y = int((1 - ease_out(min(1.0, word_age / 0.10))) * 14)

                draw_temp = ImageDraw.Draw(img)
                bbox = draw_temp.textbbox((0, 0), word_text, font=font_main)
                tw_w = bbox[2] - bbox[0]
                th_h = bbox[3] - bbox[1]
                x = cx - tw_w // 2
                y = H // 2 - th_h // 2 + slide_y

                # Backdrop
                if use_backdrop:
                    pad = 24
                    img_rgba = img.convert("RGBA")
                    if backdrop_style == "gradient":
                        # Soft radial gradient cloud
                        bw = tw_w + pad * 4
                        bh = th_h + pad * 3
                        backdrop = Image.new("RGBA", (bw, bh), (0, 0, 0, 0))
                        bd = ImageDraw.Draw(backdrop)
                        bcx, bcy = bw // 2, bh // 2
                        max_r = max(bw, bh) // 2
                        for r in range(max_r, 0, -2):
                            a = int(fade * 120 * (r / max_r) ** 0.3 * (1 - (r / max_r) ** 2))
                            bd.ellipse([bcx - r, bcy - r, bcx + r, bcy + r], fill=(0, 0, 0, max(0, min(255, a))))
                        bx = x - pad * 2
                        by = y - pad
                        img_rgba.paste(backdrop, (bx, by), backdrop)
                    else:
                        backdrop = Image.new("RGBA", (tw_w + pad * 2, th_h + pad), (0, 0, 0, int(fade * 150)))
                        img_rgba.paste(backdrop, (x - pad, y - pad // 2), backdrop)
                    img = img_rgba.convert("RGB")

                draw = ImageDraw.Draw(img)
                # Shadow
                draw.text((x + 3, y + 3), word_text, font=font_main, fill=(0, 0, 0))
                # Main text
                draw.text((x, y), word_text, font=font_main, fill=color)

        encode.stdin.write(img.tobytes())

        if frame % 150 == 0:
            pct = frame * 100 // total_frames
            print(f"  {frame}/{total_frames} ({pct}%)")

    extract.stdout.close()
    extract.wait()
    encode.stdin.close()
    encode.wait()
    print(f"Composite: {os.path.getsize(raw_video) // 1024}KB")

    # Audio mix
    final = os.path.join(project_dir, "reel_final.mp4")
    has_voice = voice_cfg.get("enabled", True) and os.path.exists(voice_file)
    has_music = music_cfg.get("enabled", False) and music_file and os.path.exists(music_file)

    if has_voice and has_music:
        print("Mixing voice + music...")
        subprocess.run([
            "ffmpeg", "-y",
            "-i", raw_video, "-i", voice_file, "-i", music_file,
            "-filter_complex",
            f"[1:a]volume={voice_vol}[v];[2:a]volume={music_vol}[m];[v][m]amix=inputs=2:duration=first[a]",
            "-map", "0:v", "-map", "[a]",
            "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest",
            final,
        ], capture_output=True)
    elif has_voice:
        print("Adding voice...")
        subprocess.run([
            "ffmpeg", "-y",
            "-i", raw_video, "-i", voice_file,
            "-map", "0:v", "-map", "1:a",
            "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest",
            final,
        ], capture_output=True)
    else:
        # No audio — just copy
        import shutil
        shutil.copy(raw_video, final)

    if os.path.exists(final):
        size_mb = os.path.getsize(final) / 1024 / 1024
        print(f"\n✅ DONE: {final} ({size_mb:.1f}MB)")
    else:
        print("❌ FAILED to create final video")


if __name__ == "__main__":
    main()
