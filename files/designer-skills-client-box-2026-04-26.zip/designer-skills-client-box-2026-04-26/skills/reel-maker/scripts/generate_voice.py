"""
Step 1: Generate voice from script sentences via ElevenLabs.
Usage: python3 generate_voice.py <config.json>
Output: voice_full.mp3 + per-sentence voice_sNN.mp3 files in project dir
"""
import json, os, sys, subprocess, requests

def main():
    config_path = sys.argv[1]
    with open(config_path) as f:
        config = json.load(f)

    project_dir = os.path.dirname(os.path.abspath(config_path))
    script = config["script"]
    voice_cfg = config.get("voice", {})

    if not voice_cfg.get("enabled", True):
        print("Voice disabled in config, skipping.")
        return

    api_key = os.environ.get("ELEVENLABS_API_KEY", "")
    if not api_key:
        print("ERROR: ELEVENLABS_API_KEY not set")
        sys.exit(1)

    lang = script.get("language", "ru")
    voice_id = voice_cfg.get("voice_id") or os.environ.get(
        f"ELEVENLABS_VOICE_ID_{lang.upper()}", ""
    )
    if not voice_id:
        print(f"ERROR: No voice_id in config and ELEVENLABS_VOICE_ID_{lang.upper()} not set")
        sys.exit(1)

    speed = voice_cfg.get("speed", 1.0)
    sentences = script["sentences"]
    parts = []

    for i, sent in enumerate(sentences):
        out_path = os.path.join(project_dir, f"voice_s{i:02d}.mp3")
        if os.path.exists(out_path) and os.path.getsize(out_path) > 1000:
            print(f"  Sentence {i}: exists, skip")
            parts.append(out_path)
            continue

        text = sent["text"]
        print(f"  Sentence {i}: '{text[:50]}...'")

        resp = requests.post(
            f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}",
            headers={
                "xi-api-key": api_key,
                "Content-Type": "application/json",
            },
            json={
                "text": text,
                "model_id": "eleven_multilingual_v2",
                "voice_settings": {
                    "stability": 0.5,
                    "similarity_boost": 0.75,
                    "speed": speed,
                },
            },
            timeout=60,
        )
        if resp.status_code != 200:
            print(f"  ERROR: {resp.status_code} {resp.text[:200]}")
            sys.exit(1)

        with open(out_path, "wb") as f:
            f.write(resp.content)
        print(f"  ✅ {os.path.getsize(out_path) // 1024}KB")
        parts.append(out_path)

    # Concatenate all parts
    full_path = os.path.join(project_dir, "voice_full.mp3")
    concat_file = os.path.join(project_dir, "voice_concat.txt")
    with open(concat_file, "w") as f:
        for p in parts:
            f.write(f"file '{p}'\n")

    subprocess.run(
        ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", concat_file, "-c", "copy", full_path],
        capture_output=True,
    )
    if os.path.exists(full_path):
        print(f"\n✅ Full voice: {full_path} ({os.path.getsize(full_path) // 1024}KB)")
    else:
        print("ERROR: Failed to concatenate voice parts")

    # Save durations
    durations = []
    for p in parts:
        dur = float(
            subprocess.check_output(
                ["ffprobe", "-v", "quiet", "-show_entries", "format=duration", "-of", "csv=p=0", p]
            ).decode().strip()
        )
        durations.append(round(dur, 3))

    dur_path = os.path.join(project_dir, "durations.json")
    with open(dur_path, "w") as f:
        json.dump(durations, f, indent=2)
    print(f"Durations saved: {dur_path}")


if __name__ == "__main__":
    main()
