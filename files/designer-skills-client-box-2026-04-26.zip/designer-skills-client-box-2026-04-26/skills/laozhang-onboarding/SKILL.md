---
name: laozhang-onboarding
description: "Генерация и редактирование изображений через LaoZhang API: Gemini 3 Pro, GPT-Image 2, GPT-Image 2 VIP, Sora2Official, OpenAI-style Images API, /v1/images/generations, /v1/images/edits, face swap, image-to-image, референсы, size/quality маршруты. Используй, когда пользователь явно просит LaoZhang, GPT-Image 2, gpt-image-2, gpt-image-2-vip, Sora2Official, images edits, image edit, image-to-image, Gemini Pro через LaoZhang, nano banana api, картинки через LaoZhang, настройку или прямой API workflow для изображений."
---

# LaoZhang — Image Generation Routes

Используй этот skill, когда картинку нужно делать **через LaoZhang**, а не через другой провайдер.

## Быстрый выбор маршрута

### 1) `gemini-3-pro-image-preview`
Используй, когда нужны:
- face swap
- identity-critical задачи
- strict reference
- референсные фото реального человека
- максимальный контроль над входными изображениями

Основной direct route:

```text
POST /v1beta/models/gemini-3-pro-image-preview:generateContent
```

### 2) `gpt-image-2`
Используй, когда нужны:
- генерация именно через **GPT-Image 2**
- OpenAI-style Images API
- простой text-to-image без сложного мультимодального Gemini flow
- совместимость с OpenAI image workflow

### 3) `gpt-image-2-vip`
Используй, когда нужны:
- GPT-Image 2
- явный common `size`
- reverse route без `quality`

## Что выбрать по умолчанию

- **Реальные люди / identity / edit / строгий референс** → `gemini-3-pro-image-preview`
- **Явно просят GPT-Image 2** → `gpt-image-2`
- **Просят GPT-Image 2 + нужен fixed size** → `gpt-image-2-vip`
- **Нужны official-style size + quality** → `gpt-image-2` через token group `Sora2Official`
- **Просят image-to-image / images edits через LaoZhang** → этот skill, `edit` command или direct `/v1/images/edits`

## Команды

### Gemini 3 Pro direct
Смотри workflow ниже и используй direct endpoint `generateContent`.

### GPT-Image 2 helper script

```bash
python3 ./scripts/laozhang_gpt_image_2.py balance
python3 ./scripts/laozhang_gpt_image_2.py generate --route default --prompt "Premium dark product render of a black ceramic mug with soft studio light"
python3 ./scripts/laozhang_gpt_image_2.py generate --route vip --prompt "Premium dark product render of a black ceramic mug with soft studio light" --size 1536x1024
python3 ./scripts/laozhang_gpt_image_2.py generate --route official --prompt "Premium dark product render of a black ceramic mug with soft studio light" --size 1536x1024 --quality high
python3 ./scripts/laozhang_gpt_image_2.py edit --route default --image /path/to/source.png --prompt "Keep the composition and product, change the sticker to red and add a thin gold rim"
python3 ./scripts/laozhang_gpt_image_2.py edit --route official --image /path/to/source.png --prompt "Keep the composition and product, change the sticker to green" --size 1024x1024 --quality high
```

`balance` is optional: some LaoZhang gateways return 404 for the balance endpoint, so if that happens, check the LaoZhang dashboard and continue with generation.

`edit` uses synchronous multipart `POST /v1/images/edits` with local image upload. На текущей доке LaoZhang для `gpt-image-2` нет нормального async/webhook callback flow, поэтому не выдумывай callback: используй sync edit endpoint и сразу сохраняй результат локально.

## GPT-Image 2 rules

### Default route
- model: `gpt-image-2`
- endpoints: `/v1/images/generations`, `/v1/images/edits`, optionally `/v1/chat/completions` for reverse-route chat workflows
- `size`: not supported
- `quality`: not supported

### VIP route
- model: `gpt-image-2-vip`
- endpoints: `/v1/images/generations`, `/v1/images/edits`, optionally `/v1/chat/completions`
- `size`: supported
- `quality`: not supported
- common sizes only

### Official route
- model: `gpt-image-2`
- token group must be `Sora2Official`
- endpoints: `/v1/images/generations`, `/v1/images/edits`
- `size`: supported
- `quality`: supported

## VIP sizes
- `1024x1024`
- `1536x1024`
- `1024x1536`
- `2048x2048`
- `2048x1152`
- `auto`

Do **not** treat VIP as a real 4K route.

## Official sizes and quality
Official route can use:
- sizes: `1024x1024`, `1536x1024`, `1024x1536`, `2048x2048`, `2048x1152`, `3840x2160`, `2160x3840`, `auto`
- quality: `low`, `medium`, `high`, `auto`

## Where outputs go

GPT-Image 2 helper saves outputs to:

```text
~/.openclaw/generated/laozhang-gpt-image-2/
```

## References

Read these when needed:
- `references/gpt-image-2.md` — LaoZhang GPT-Image 2 route matrix, params, examples

## Existing Gemini 3 Pro workflow

### Correct endpoint

```text
POST https://api.laozhang.ai/v1beta/models/gemini-3-pro-image-preview:generateContent
```

### Rules for Gemini 3 Pro
1. Use prompt in English.
2. Use `responseModalities: ["IMAGE"]`.
3. Use `imageConfig`.
4. For real people, use only real reference photos.
5. If identity is wrong, regenerate — do not send.

### Example

```bash
curl -X POST "https://api.laozhang.ai/v1beta/models/gemini-3-pro-image-preview:generateContent" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $LAOZHANG_API_KEY" \
  --max-time 180 \
  -d '{
    "contents": [{
      "parts": [{"text": "Generate an image: cinematic portrait of a confident AI founder in a dark luxury studio, realistic skin texture, premium black outfit, dramatic rim light, editorial photography"}]
    }],
    "generationConfig": {
      "responseModalities": ["IMAGE"],
      "imageConfig": {
        "aspectRatio": "3:4",
        "imageSize": "4K"
      }
    }
  }'
```

## Decision rule

If the user says one of these:
- "через LaoZhang GPT-Image 2"
- "через gpt-image-2"
- "через gpt-image-2-vip"
- "через Sora2Official"
- "OpenAI-style images API через LaoZhang"
- "images edits через LaoZhang"
- "image-to-image через LaoZhang"

then choose GPT-Image 2 route first.

If the user says one of these:
- "face swap"
- "замени лицо"
- "сохрани лицо"
- "по этим фото"
- "строго по референсу"

then choose direct Gemini 3 Pro first.
