#!/usr/bin/env python3
import argparse
import base64
import contextlib
import json
import os
import pathlib
import sys
import time
from urllib.parse import urlparse

import requests

BASE_URL = "https://api.laozhang.ai/v1"
CONFIG_PATH = os.path.expanduser("~/.openclaw/openclaw.json")
DEFAULT_OUTPUT_ROOT = os.path.expanduser("~/.openclaw/generated/laozhang-gpt-image-2")
BALANCE_PATH = "/user/balance"
GENERATE_PATH = "/images/generations"
EDIT_PATH = "/images/edits"

VIP_SIZES = {"1024x1024", "1536x1024", "1024x1536", "2048x2048", "2048x1152", "auto"}
OFFICIAL_SIZES = VIP_SIZES | {"3840x2160", "2160x3840"}
OFFICIAL_QUALITIES = {"low", "medium", "high", "auto"}


def load_api_key() -> str:
    key = os.getenv("LAOZHANG_API_KEY")
    if key:
        return key
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("env", {}).get("vars", {}).get("LAOZHANG_API_KEY", "")
    except Exception:
        return ""


API_KEY = load_api_key()


def die(message: str, code: int = 1):
    print(json.dumps({"ok": False, "error": message}, ensure_ascii=False))
    sys.exit(code)


if not API_KEY:
    die("LAOZHANG_API_KEY not found in env or ~/.openclaw/openclaw.json")


def api_headers(json_body: bool = True):
    headers = {"Authorization": f"Bearer {API_KEY}"}
    if json_body:
        headers["Content-Type"] = "application/json"
    return headers


def request_json(method: str, path: str, *, json_body=None, timeout=180):
    url = f"{BASE_URL}{path}"
    response = requests.request(method, url, headers=api_headers(json_body is not None), json=json_body, timeout=timeout)
    try:
        data = response.json()
    except Exception:
        raise RuntimeError(f"Non-JSON response from {url}: HTTP {response.status_code} {response.text[:500]}")
    if response.status_code >= 400:
        raise RuntimeError(f"HTTP {response.status_code} from {url}: {json.dumps(data, ensure_ascii=False)}")
    return data


def request_multipart(path: str, *, data_fields, file_fields, timeout=180):
    url = f"{BASE_URL}{path}"
    response = requests.post(url, headers=api_headers(False), data=data_fields, files=file_fields, timeout=timeout)
    try:
        data = response.json()
    except Exception:
        raise RuntimeError(f"Non-JSON response from {url}: HTTP {response.status_code} {response.text[:500]}")
    if response.status_code >= 400:
        raise RuntimeError(f"HTTP {response.status_code} from {url}: {json.dumps(data, ensure_ascii=False)}")
    return data


def validate_route_options(route: str, size: str | None, quality: str | None):
    if route == "default":
        if size:
            raise ValueError("Default LaoZhang gpt-image-2 route does not support --size")
        if quality:
            raise ValueError("Default LaoZhang gpt-image-2 route does not support --quality")
    elif route == "vip":
        if quality:
            raise ValueError("VIP route does not support --quality")
        if size and size not in VIP_SIZES:
            raise ValueError(f"VIP route supports only: {sorted(VIP_SIZES)}")
    elif route == "official":
        if size and size not in OFFICIAL_SIZES:
            raise ValueError(f"Official route supports only: {sorted(OFFICIAL_SIZES)}")
        if quality and quality not in OFFICIAL_QUALITIES:
            raise ValueError(f"Official route quality supports only: {sorted(OFFICIAL_QUALITIES)}")


def validate_generate_args(args):
    validate_route_options(args.route, args.size, args.quality)


def validate_edit_args(args):
    validate_route_options(args.route, args.size, args.quality)
    if not args.image:
        raise ValueError("Provide at least one --image path")
    for path in args.image:
        if not os.path.isfile(path):
            raise ValueError(f"Image file not found: {path}")


def resolve_model(route: str) -> str:
    if route == "vip":
        return "gpt-image-2-vip"
    return "gpt-image-2"


def fetch_balance(_args):
    url = f"{BASE_URL}{BALANCE_PATH}"
    response = requests.get(url, headers=api_headers(False), timeout=60)
    try:
        data = response.json()
    except Exception:
        data = {"raw": response.text[:500]}
    if response.status_code == 404:
        print(json.dumps({
            "ok": False,
            "supported": False,
            "error": "Balance endpoint is unavailable on the current LaoZhang gateway. Check the LaoZhang dashboard instead.",
            "response": data,
        }, ensure_ascii=False, indent=2))
        return
    if response.status_code >= 400:
        raise RuntimeError(f"HTTP {response.status_code} from {url}: {json.dumps(data, ensure_ascii=False)}")
    print(json.dumps({"ok": True, "balance": data}, ensure_ascii=False, indent=2))


def save_b64_image(value: str, output_dir: str, filename: str = "image-1.png"):
    if value.startswith("data:"):
        value = value.split(",", 1)[1]
    value += "=" * ((4 - len(value) % 4) % 4)
    raw = base64.b64decode(value)
    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, filename)
    with open(path, "wb") as f:
        f.write(raw)
    return path


def download_url(url: str, output_dir: str, filename: str = None):
    response = requests.get(url, timeout=180)
    response.raise_for_status()
    os.makedirs(output_dir, exist_ok=True)
    if not filename:
        ext = pathlib.Path(urlparse(url).path).suffix or ".png"
        filename = f"image-1{ext}"
    path = os.path.join(output_dir, filename)
    with open(path, "wb") as f:
        f.write(response.content)
    return path


def normalize_items(data: dict):
    items = data.get("data") or []
    if isinstance(items, dict):
        items = [items]
    return items


def save_result_items(items, output_dir: str):
    saved = []
    for index, item in enumerate(items, start=1):
        if item.get("b64_json"):
            saved.append(save_b64_image(item["b64_json"], output_dir, filename=f"image-{index}.png"))
        elif item.get("url"):
            filename = None if index == 1 else f"image-{index}.png"
            saved.append(download_url(item["url"], output_dir, filename=filename))
        else:
            raise RuntimeError(f"Unsupported response payload: {json.dumps(item, ensure_ascii=False)}")
    return saved


def build_response_meta(data: dict, items):
    first = items[0] if items else {}
    return {
        "created": data.get("created"),
        "usage": data.get("usage"),
        "itemCount": len(items),
        "returned": {
            "hasB64": bool(first.get("b64_json")),
            "hasUrl": bool(first.get("url")),
        },
    }


def generate(args):
    validate_generate_args(args)
    payload = {
        "model": resolve_model(args.route),
        "prompt": args.prompt,
    }
    if args.size:
        payload["size"] = args.size
    if args.quality:
        payload["quality"] = args.quality

    started = int(time.time())
    data = request_json("POST", GENERATE_PATH, json_body=payload, timeout=args.timeout_seconds)
    items = normalize_items(data)
    if not items:
        raise RuntimeError(f"No image data returned: {json.dumps(data, ensure_ascii=False)}")
    output_dir = os.path.join(args.output_root, f"{args.route}-{started}")
    saved = save_result_items(items, output_dir)
    response_meta = build_response_meta(data, items)

    print(json.dumps({
        "ok": True,
        "provider": "laozhang",
        "operation": "generate",
        "route": args.route,
        "model": resolve_model(args.route),
        "saved": saved,
        "responseMeta": response_meta,
    }, ensure_ascii=False, indent=2))


def edit_image(args):
    validate_edit_args(args)
    started = int(time.time())
    form_fields = [("model", resolve_model(args.route)), ("prompt", args.prompt)]
    if args.size:
        form_fields.append(("size", args.size))
    if args.quality:
        form_fields.append(("quality", args.quality))

    with contextlib.ExitStack() as stack:
        file_fields = []
        for path in args.image:
            handle = stack.enter_context(open(path, "rb"))
            file_fields.append(("image", (os.path.basename(path), handle, "application/octet-stream")))
        data = request_multipart(EDIT_PATH, data_fields=form_fields, file_fields=file_fields, timeout=args.timeout_seconds)

    items = normalize_items(data)
    if not items:
        raise RuntimeError(f"No image data returned: {json.dumps(data, ensure_ascii=False)}")
    output_dir = os.path.join(args.output_root, f"edit-{args.route}-{started}")
    saved = save_result_items(items, output_dir)
    response_meta = build_response_meta(data, items)

    print(json.dumps({
        "ok": True,
        "provider": "laozhang",
        "operation": "edit",
        "route": args.route,
        "model": resolve_model(args.route),
        "inputImages": args.image,
        "saved": saved,
        "responseMeta": response_meta,
    }, ensure_ascii=False, indent=2))


def build_parser():
    parser = argparse.ArgumentParser(description="LaoZhang GPT-Image 2 helper")
    sub = parser.add_subparsers(dest="command", required=True)

    balance = sub.add_parser("balance", help="Check LaoZhang balance")
    balance.set_defaults(func=fetch_balance)

    gen = sub.add_parser("generate", help="Generate image with LaoZhang GPT-Image 2")
    gen.add_argument("--route", choices=["default", "vip", "official"], default="default")
    gen.add_argument("--prompt", required=True)
    gen.add_argument("--size")
    gen.add_argument("--quality")
    gen.add_argument("--timeout-seconds", type=int, default=180)
    gen.add_argument("--output-root", default=DEFAULT_OUTPUT_ROOT)
    gen.set_defaults(func=generate)

    edit = sub.add_parser("edit", help="Edit local image(s) with LaoZhang GPT-Image 2 via /images/edits")
    edit.add_argument("--route", choices=["default", "vip", "official"], default="default")
    edit.add_argument("--prompt", required=True)
    edit.add_argument("--image", action="append", required=True, help="Local image path; repeat for multiple images")
    edit.add_argument("--size")
    edit.add_argument("--quality")
    edit.add_argument("--timeout-seconds", type=int, default=180)
    edit.add_argument("--output-root", default=DEFAULT_OUTPUT_ROOT)
    edit.set_defaults(func=edit_image)

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    try:
        args.func(args)
    except KeyboardInterrupt:
        die("Interrupted", 130)
    except Exception as e:
        die(str(e), 1)


if __name__ == "__main__":
    main()
