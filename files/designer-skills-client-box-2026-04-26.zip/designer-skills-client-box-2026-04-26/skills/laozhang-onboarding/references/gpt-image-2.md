# LaoZhang GPT-Image 2 Reference

## Base
- Base URL: `https://api.laozhang.ai/v1`
- Auth: `Authorization: Bearer <LAOZHANG_API_KEY>`
- Main endpoint for generation: `POST /images/generations`

## Route matrix

| Route | Token group | Model | Size | Quality | Endpoints | Notes |
|---|---|---|---|---|---|---|
| Default | default group | `gpt-image-2` | No | No | `/images/generations`, `/images/edits`, optional `/chat/completions` | Fastest simple route, `$0.03/call` |
| VIP | default group | `gpt-image-2-vip` | Yes, common sizes only | No | `/images/generations`, `/images/edits`, optional `/chat/completions` | Reverse Codex route, `$0.03/call` |
| Official | `Sora2Official` group | `gpt-image-2` | Yes | Yes | `/images/generations`, `/images/edits` | Official-style Images API |

## When to use what

### `gpt-image-2`
Use when:
- the user explicitly asks for **GPT-Image 2**
- you want an OpenAI-style image workflow through LaoZhang
- you do not need hard size control on the default route

### `gpt-image-2-vip`
Use when:
- the user wants **GPT-Image 2**
- you need a fixed common size
- you are on the reverse route and do not need `quality`

### `gpt-image-2` with `Sora2Official`
Use when:
- you need official-like compatibility
- you need `quality`
- you need 4K-style sizes like `3840x2160` or `2160x3840`

## Supported sizes

### VIP route
- `1024x1024`
- `1536x1024`
- `1024x1536`
- `2048x2048`
- `2048x1152`
- `auto`

### Official route
- `1024x1024`
- `1536x1024`
- `1024x1536`
- `2048x2048`
- `2048x1152`
- `3840x2160`
- `2160x3840`
- `auto`

## Quality values
Official route only:
- `low`
- `medium`
- `high`
- `auto`

## Important limits
- Default `gpt-image-2` route: do **not** pass `size` or `quality`
- VIP route: pass `size` only, do **not** pass `quality`
- VIP route: treat `3840x2160` and `2160x3840` as unsupported
- Official route: use `/v1/images/generations`, not `/v1/chat/completions`

## Images edits

### What is supported
- local multipart upload via `POST /images/edits`
- one or more `image` fields
- `size` and `quality` follow the same route rules as generation

### What is not documented here
- no proper async task API
- no documented webhook callback flow for `gpt-image-2`

Treat LaoZhang GPT-Image 2 edits as synchronous HTTP responses and save outputs locally immediately.

### Edit example: default route
```bash
curl "https://api.laozhang.ai/v1/images/edits" \
  -H "Authorization: Bearer $LAOZHANG_API_KEY" \
  -F "model=gpt-image-2" \
  -F "prompt=Use the provided image as the source. Keep the subject and composition. Change the sticker to red and add a thin gold rim." \
  -F "image=@source.png"
```

### Edit example: official route
```bash
curl "https://api.laozhang.ai/v1/images/edits" \
  -H "Authorization: Bearer $LAOZHANG_API_KEY" \
  -F "model=gpt-image-2" \
  -F "prompt=Use the provided image as the source. Keep the subject and composition. Change the sticker to green." \
  -F "image=@source.png" \
  -F "size=1024x1024" \
  -F "quality=high"
```

## Response parsing

### `b64_json`
Typical Images API response:

```json
{
  "data": [
    {
      "b64_json": "iVBORw0KGgo..."
    }
  ]
}
```

### `url`
Some routes can return:

```json
{
  "data": [
    {
      "url": "https://.../output.png"
    }
  ]
}
```

## Minimal examples

### Default route
```bash
curl "https://api.laozhang.ai/v1/images/generations" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $LAOZHANG_API_KEY" \
  -d '{
    "model": "gpt-image-2",
    "prompt": "Create a premium dark product poster of a black ceramic mug with soft studio light"
  }'
```

### VIP route
```bash
curl "https://api.laozhang.ai/v1/images/generations" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $LAOZHANG_API_KEY" \
  -d '{
    "model": "gpt-image-2-vip",
    "prompt": "Create a premium dark product poster of a black ceramic mug with soft studio light",
    "size": "1536x1024"
  }'
```

### Official route
```bash
curl "https://api.laozhang.ai/v1/images/generations" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $LAOZHANG_API_KEY" \
  -d '{
    "model": "gpt-image-2",
    "prompt": "Create a premium dark product poster of a black ceramic mug with soft studio light",
    "size": "1536x1024",
    "quality": "high"
  }'
```
