---
name: image-gen
description: Генерация и редактирование изображений — Nano Banana, LaoZhang Gemini Pro, LaoZhang GPT-Image 2, GPT-Image 2 VIP, Sora2Official, image-to-image, images edits, промпты, identity-kit, обложки
metadata:
  {
    "openclaw": { "emoji": "🖼️" }
  }
---

# Image Gen — Генерация изображений

Создание изображений через Nano Banana и LaoZhang routes: от простых картинок до фотореалистичных портретов, GPT-Image 2 generation, постоянных персонажей и обложек.

## Context Loading (обязательно перед работой)
1. Читай `brand/voice-style.md` → тон и стиль
2. Читай `brand/audience.md` → для кого
3. Читай `learning/approved-patterns.md` → что работает
4. Читай `learning/rejected-patterns.md` → чего избегать
5. Если есть `brand/personal-dna.md` → подтягивай личность

## File Router

| Задача | Подпапка | Что там |
|--------|----------|---------|
| Генерация изображений (основное) | `{baseDir}/nano-banana/` | Реализм, словарь, примеры, идеи |
| LaoZhang provider routes | `{baseDir}/laozhang-onboarding/` | Gemini Pro, GPT-Image 2, size/quality маршруты, API workflow |
| Библиотека продвинутых промптов | `{baseDir}/pro-prompts/` | Готовые шаблоны для разных задач |
| Identity Kit (постоянные персонажи) | `{baseDir}/identity-kit/` | Создание и поддержка AI-персонажей |
| Обложки и thumbnails | `{baseDir}/thumbnails/` | Промпты для обложек видео и постов |

## Workflow

1. **Определи задачу** → простое фото / портрет / персонаж / обложка / GPT-Image 2 route
2. **Выбери подпапку** → nano-banana для prompt-work, laozhang-onboarding для provider route и API выбора, pro-prompts для шаблонов
3. **Выбери модель** → Gemini Pro для identity/edit/reference-heavy задач; GPT-Image 2 для OpenAI-style image workflow, `/images/edits`, `Sora2Official` или когда пользователь просит именно его
4. **Составь промпт** → специфика > неопределённость, описание сцены > ключевые слова
5. **Сгенерируй или отредактируй** → через нужный LaoZhang route
6. **Итерируй** → уточняй промпт по результату

## Ключевые файлы по подпапкам

### nano-banana/
- `nano-banana-realism.md` — фотореалистичная генерация
- `nano-banana-vocabulary.md` — словарь терминов для промптов
- `nano-banana-examples.md` — примеры успешных промптов
- `nano-banana-ideas.md` — идеи для генерации

### pro-prompts/
- Готовые промпты для портретов, аватаров, обложек, каруселей

### identity-kit/
- `identity-kit.md` — создание постоянных AI-персонажей

### thumbnails/
- `thumbnails.md` — промпты для обложек видео
