---
name: design-toolkit
description: "Единый тулкит для UI/UX: поиск стилей и палитр (UI UX Pro Max), генерация компонентов (21st.dev Magic), генерация полных экранов/мокапов (Google Stitch). Активируется на: дизайн, UI, UX, компонент, мокап, лендинг, стиль, палитра, шрифт, экран, макет, design, mockup, component, layout."
---

# Design Toolkit

3 инструмента для UI/UX работы. Используй в правильном порядке.

## Decision Tree

```
Задача → Какой инструмент?

"Найди стиль / палитру / шрифт / UX-правило"
  → UI UX Pro Max (поиск по базе)

"Сгенери кнопку / карточку / форму / компонент"
  → 21st.dev Magic (React/Tailwind компоненты)

"Сгенери целый экран / мокап / превью сайта"
  → Google Stitch (полные HTML/CSS экраны)

Типичный пайплайн:
1. UI UX Pro Max → выбрать стиль, палитру, шрифты
2. Stitch → сгенерить мокап экрана
3. 21st.dev → доработать отдельные компоненты
```

## 1. UI UX Pro Max — поиск по дизайн-базе

50+ стилей, палитры, шрифтовые пары, 99 UX-гайдлайнов. Без API ключей.

```bash
python3 skills/ui-ux-pro-max/scripts/search.py "<запрос>" --domain <домен> [-n <макс>]
```

### Домены
| Домен | Что ищет |
|-------|----------|
| `style` | UI стили (glassmorphism, minimalism, brutalism) + CSS |
| `color` | Палитры по типу продукта |
| `typography` | Шрифтовые пары (Google Fonts) |
| `landing` | Структура страниц, CTA стратегии |
| `ux` | Best practices и антипаттерны (99 правил) |
| `chart` | Типы графиков |
| `product` | Рекомендации по типу продукта (SaaS, e-commerce, portfolio) |

### Стеки
```bash
python3 skills/ui-ux-pro-max/scripts/search.py "<запрос>" --stack <стек>
```
Стеки: `html-tailwind`, `react`, `nextjs`, `astro`, `vue`, `svelte`, `shadcn`

### Примеры
```bash
# Найти стиль для EdTech лендинга
python3 skills/ui-ux-pro-max/scripts/search.py "modern edtech" --domain style

# Палитра для курса по нейросетям
python3 skills/ui-ux-pro-max/scripts/search.py "AI tech dark" --domain color

# UX правила для форм оплаты
python3 skills/ui-ux-pro-max/scripts/search.py "checkout form" --domain ux
```

## 2. 21st.dev Magic — генерация UI компонентов

MCP-сервер. Генерирует готовые React/Tailwind компоненты по описанию (shadcn/ui маркетплейс).

### Запуск
```bash
API_KEY="$(cat ~/.openclaw/secrets/21st-dev-api-key)" npx -y @21st-dev/magic@latest
```

### Конфиг
MCP настроен в `~/.claude/mcp.json`:
```json
{
  "@21st-dev/magic": {
    "command": "npx",
    "args": ["-y", "@21st-dev/magic@latest"],
    "env": { "API_KEY": "<key>" }
  }
}
```

### Когда использовать
- Нужен конкретный компонент: кнопка, карточка, форма, навбар, хедер
- Нужен shadcn/ui совместимый код
- Быстрая генерация без ручной вёрстки

### Примеры запросов
- "Pricing card with 3 tiers, dark theme, orange accents"
- "Hero section with gradient background and CTA button"
- "Testimonial carousel with avatar and rating"

## 3. Google Stitch — генерация полных экранов

MCP-сервер от Google. Генерирует полные UI мокапы/экраны (HTML/CSS).

### Запуск
```bash
GOOGLE_CLOUD_PROJECT=<YOUR_GCP_PROJECT> npx @_davideast/stitch-mcp proxy
```

### Конфиг
MCP настроен в `~/.claude/mcp.json`:
```json
{
  "stitch": {
    "command": "npx",
    "args": ["@_davideast/stitch-mcp", "proxy"],
    "env": { "GOOGLE_CLOUD_PROJECT": "<YOUR_GCP_PROJECT>" }
  }
}
```

### gcloud auth
- Project: `<YOUR_GCP_PROJECT>`
- Account: `<YOUR_GOOGLE_ACCOUNT_EMAIL>`
- Если нужна реавторизация: `gcloud auth login --project <YOUR_GCP_PROJECT>`

### Команды
| Команда | Что делает |
|---------|-----------|
| `serve` | Запуск локального сервера для превью |
| `site` | Генерация полного сайта |
| `screens` | Генерация отдельных экранов |
| `snapshot` | Скриншот текущего состояния |

### Когда использовать
- Нужен полный макет страницы/экрана
- Быстрый прототип лендинга
- Превью дизайна перед кодингом
- Мокапы для согласования с клиентом

### Примеры запросов
- "Landing page for AI course, dark theme, pricing section"
- "Dashboard with sidebar, charts, and user table"
- "Mobile app onboarding flow, 3 screens"

## Пайплайн: реальный пример

**Задача:** Сделать лендинг для курса "вашего продукта"

```
Шаг 1: Стиль и палитра
$ python3 skills/ui-ux-pro-max/scripts/search.py "tech education dark" --domain style
$ python3 skills/ui-ux-pro-max/scripts/search.py "AI neural network" --domain color
$ python3 skills/ui-ux-pro-max/scripts/search.py "modern heading body" --domain typography

Шаг 2: Мокап через Stitch
→ "Landing page for online AI course, dark theme with orange accents,
   hero + features + pricing + testimonials + CTA"

Шаг 3: Компоненты через 21st.dev
→ "Pricing card component, 3 tiers, dark bg, orange primary"
→ "Testimonial card with avatar, star rating, quote"
```
