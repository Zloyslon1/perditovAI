---
name: ui-ux-pro-max
description: UI/UX research kit for fast design direction: product patterns, style systems, typography pairs, color palettes, landing structures, chart choices, and UX best practices. Use when the user needs visual direction, UI references, landing structure, design critique, or fast style exploration.
---

# UI UX Pro Max

Design intelligence for building professional UI/UX. 50+ стилей, палитры, шрифтовые пары, 99 UX-гайдлайнов.

## Поиск

```bash
python3 skills/ui-ux-pro-max/scripts/search.py "<query>" --domain <domain> [-n <max>]
```

### Домены
- `product` — рекомендации по типу продукта (SaaS, e-commerce, portfolio)
- `style` — UI стили (glassmorphism, minimalism, brutalism) + CSS
- `typography` — шрифтовые пары с Google Fonts
- `color` — палитры по типу продукта
- `landing` — структура страниц и CTA стратегии
- `chart` — типы графиков
- `ux` — best practices и антипаттерны

### Стеки
```bash
python3 skills/ui-ux-pro-max/scripts/search.py "<query>" --stack <stack>
```
Стеки: `html-tailwind`, `react`, `nextjs`, `astro`, `vue`, `svelte`, `shadcn`

## Когда использовать
- Перед созданием UI — найти стиль, палитру, шрифты
- При вёрстке лендинга — структура секций, CTA placement
- Для ревью дизайна — UX guidelines и антипаттерны
