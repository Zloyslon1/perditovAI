#!/usr/bin/env python3
"""
notion_master.py — Full Notion API management for OpenClaw agents.
No external dependencies — uses only Python stdlib.
"""

import sys
import os
import json
import argparse
import urllib.request
import urllib.error
import urllib.parse

NOTION_API_KEY = os.getenv('NOTION_API_KEY', '')
NOTION_VERSION = '2022-06-28'
BASE_URL = 'https://api.notion.com/v1'

if not NOTION_API_KEY:
    print('ERROR: set NOTION_API_KEY before using notion_master.py')
    sys.exit(1)


# ─── HTTP helpers ────────────────────────────────────────────────────────────

def _request(method, path, data=None, params=None):
    url = BASE_URL + path
    if params:
        url += '?' + urllib.parse.urlencode(params)
    headers = {
        'Authorization': f'Bearer {NOTION_API_KEY}',
        'Notion-Version': NOTION_VERSION,
        'Content-Type': 'application/json',
    }
    body = json.dumps(data).encode('utf-8') if data is not None else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        raw = e.read().decode('utf-8')
        try:
            err = json.loads(raw)
        except Exception:
            err = {'message': raw}
        print(json.dumps({
            'error': err.get('message', str(e)),
            'code': err.get('code', ''),
            'status': e.code,
        }, ensure_ascii=False, indent=2))
        sys.exit(1)


def GET(path, params=None):
    return _request('GET', path, params=params)

def POST(path, data):
    return _request('POST', path, data=data)

def PATCH(path, data):
    return _request('PATCH', path, data=data)

def DELETE(path):
    return _request('DELETE', path)


def out(obj):
    print(json.dumps(obj, ensure_ascii=False, indent=2))


# ─── Rich text helper ─────────────────────────────────────────────────────────

def rich_text(content, bold=False, italic=False, color=None):
    t = {'type': 'text', 'text': {'content': content}}
    ann = {}
    if bold:   ann['bold'] = True
    if italic: ann['italic'] = True
    if color:  ann['color'] = color
    if ann:    t['annotations'] = ann
    return [t]


# ─── Search ───────────────────────────────────────────────────────────────────

def cmd_search(args):
    data = {'query': args.query or '', 'page_size': args.limit}
    if args.filter:
        data['filter'] = {'value': args.filter, 'property': 'object'}
    out(POST('/search', data))


# ─── Pages ────────────────────────────────────────────────────────────────────

def cmd_page_get(args):
    out(GET(f'/pages/{args.id}'))


def cmd_page_create(args):
    if not args.parent_page and not args.parent_db:
        print('ERROR: specify --parent-page or --parent-db')
        sys.exit(1)
    parent = (
        {'type': 'page_id',     'page_id':     args.parent_page} if args.parent_page else
        {'type': 'database_id', 'database_id': args.parent_db}
    )
    props = {
        'title': {'title': rich_text(args.title)}
    }
    if args.props:
        props.update(json.loads(args.props))
    data = {'parent': parent, 'properties': props}
    if args.content:
        children = json.loads(args.content)
        data['children'] = children if isinstance(children, list) else [children]
    if args.icon:
        data['icon'] = json.loads(args.icon)
    if args.cover:
        data['cover'] = json.loads(args.cover)
    out(POST('/pages', data))


def cmd_page_update(args):
    data = {}
    if args.title:
        data['properties'] = {'title': {'title': rich_text(args.title)}}
    if args.props:
        data.setdefault('properties', {}).update(json.loads(args.props))
    if args.icon:
        data['icon'] = json.loads(args.icon)
    if args.cover:
        data['cover'] = json.loads(args.cover)
    if not data:
        print('ERROR: nothing to update — provide at least one of --title, --props, --icon, --cover')
        sys.exit(1)
    out(PATCH(f'/pages/{args.id}', data))


def cmd_page_archive(args):
    PATCH(f'/pages/{args.id}', {'archived': True})
    out({'ok': True, 'archived': args.id})


def cmd_page_unarchive(args):
    PATCH(f'/pages/{args.id}', {'archived': False})
    out({'ok': True, 'unarchived': args.id})


def cmd_page_content(args):
    params = {'page_size': args.limit}
    if args.cursor:
        params['start_cursor'] = args.cursor
    out(GET(f'/blocks/{args.id}/children', params=params))


def cmd_page_move(args):
    if not args.to_page and not args.to_db:
        print('ERROR: specify --to-page or --to-db')
        sys.exit(1)
    parent = (
        {'type': 'page_id',     'page_id':     args.to_page} if args.to_page else
        {'type': 'database_id', 'database_id': args.to_db}
    )
    out(PATCH(f'/pages/{args.id}', {'parent': parent}))


# ─── Blocks ───────────────────────────────────────────────────────────────────

def cmd_block_get(args):
    out(GET(f'/blocks/{args.id}'))


def cmd_block_children(args):
    params = {'page_size': args.limit}
    if args.cursor:
        params['start_cursor'] = args.cursor
    out(GET(f'/blocks/{args.id}/children', params=params))


def cmd_block_append(args):
    children = json.loads(args.content)
    if isinstance(children, dict):
        children = [children]
    out(PATCH(f'/blocks/{args.id}/children', {'children': children}))


def cmd_block_update(args):
    data = json.loads(args.content)
    out(PATCH(f'/blocks/{args.id}', data))


def cmd_block_delete(args):
    DELETE(f'/blocks/{args.id}')
    out({'ok': True, 'deleted': args.id})


# ─── Databases ────────────────────────────────────────────────────────────────

def cmd_db_get(args):
    out(GET(f'/databases/{args.id}'))


def cmd_db_create(args):
    schema = json.loads(args.schema) if args.schema else {'Name': {'title': {}}}
    data = {
        'parent': {'type': 'page_id', 'page_id': args.parent_page},
        'title': [{'type': 'text', 'text': {'content': args.title}}],
        'properties': schema,
    }
    if args.inline:
        data['is_inline'] = True
    out(POST('/databases', data))


def cmd_db_update(args):
    data = {}
    if args.title:
        data['title'] = [{'type': 'text', 'text': {'content': args.title}}]
    if args.schema:
        data['properties'] = json.loads(args.schema)
    if not data:
        print('ERROR: provide at least --title or --schema')
        sys.exit(1)
    out(PATCH(f'/databases/{args.id}', data))


def cmd_db_query(args):
    data = {'page_size': args.limit}
    if args.filter:
        data['filter'] = json.loads(args.filter)
    if args.sort:
        sorts = json.loads(args.sort)
        data['sorts'] = sorts if isinstance(sorts, list) else [sorts]
    if args.cursor:
        data['start_cursor'] = args.cursor
    out(POST(f'/databases/{args.id}/query', data))


def cmd_db_item_create(args):
    props = json.loads(args.props)
    data = {
        'parent': {'database_id': args.id},
        'properties': props,
    }
    if args.content:
        children = json.loads(args.content)
        data['children'] = children if isinstance(children, list) else [children]
    if args.icon:
        data['icon'] = json.loads(args.icon)
    out(POST('/pages', data))


# ─── Comments ────────────────────────────────────────────────────────────────

def cmd_comment_create(args):
    data = {
        'parent': {'page_id': args.id},
        'rich_text': rich_text(args.text),
    }
    out(POST('/comments', data))


def cmd_comment_list(args):
    out(GET(f'/comments', params={'block_id': args.id}))


# ─── Users ───────────────────────────────────────────────────────────────────

def cmd_users(args):
    out(GET('/users'))


def cmd_me(args):
    out(GET('/users/me'))


# ─── CLI setup ───────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        prog='notion_master.py',
        description='Full Notion API management — pages, blocks, databases, search'
    )
    sub = parser.add_subparsers(dest='cmd', required=True)

    # ── search ──
    p = sub.add_parser('search', help='Search workspace')
    p.add_argument('query', nargs='?', default='', help='Search query')
    p.add_argument('--filter', choices=['page', 'database'], help='Object type filter')
    p.add_argument('--limit', type=int, default=20)
    p.set_defaults(func=cmd_search)

    # ── page-get ──
    p = sub.add_parser('page-get', help='Get page properties')
    p.add_argument('id', help='Page ID')
    p.set_defaults(func=cmd_page_get)

    # ── page-create ──
    p = sub.add_parser('page-create', help='Create a new page')
    p.add_argument('--parent-page', metavar='ID', help='Parent page ID')
    p.add_argument('--parent-db',   metavar='ID', help='Parent database ID')
    p.add_argument('--title', required=True)
    p.add_argument('--props',   metavar='JSON', help='Extra properties as JSON object')
    p.add_argument('--content', metavar='JSON', help='Initial blocks as JSON array')
    p.add_argument('--icon',    metavar='JSON', help='Icon as JSON, e.g. {"type":"emoji","emoji":"🔥"}')
    p.add_argument('--cover',   metavar='JSON', help='Cover as JSON, e.g. {"type":"external","external":{"url":"https://..."}}')
    p.set_defaults(func=cmd_page_create)

    # ── page-update ──
    p = sub.add_parser('page-update', help='Update page title/properties/icon/cover')
    p.add_argument('id', help='Page ID')
    p.add_argument('--title')
    p.add_argument('--props',  metavar='JSON')
    p.add_argument('--icon',   metavar='JSON')
    p.add_argument('--cover',  metavar='JSON')
    p.set_defaults(func=cmd_page_update)

    # ── page-archive ──
    p = sub.add_parser('page-archive', help='Archive (soft-delete) a page')
    p.add_argument('id')
    p.set_defaults(func=cmd_page_archive)

    # ── page-unarchive ──
    p = sub.add_parser('page-unarchive', help='Restore an archived page')
    p.add_argument('id')
    p.set_defaults(func=cmd_page_unarchive)

    # ── page-content ──
    p = sub.add_parser('page-content', help='Get page block content (children)')
    p.add_argument('id', help='Page ID')
    p.add_argument('--limit', type=int, default=100)
    p.add_argument('--cursor', help='Pagination cursor')
    p.set_defaults(func=cmd_page_content)

    # ── page-move ──
    p = sub.add_parser('page-move', help='Move page to new parent')
    p.add_argument('id', help='Page ID')
    p.add_argument('--to-page', metavar='ID')
    p.add_argument('--to-db',   metavar='ID')
    p.set_defaults(func=cmd_page_move)

    # ── block-get ──
    p = sub.add_parser('block-get', help='Get a single block')
    p.add_argument('id', help='Block ID')
    p.set_defaults(func=cmd_block_get)

    # ── block-children ──
    p = sub.add_parser('block-children', help='List children of a block/page')
    p.add_argument('id', help='Block or page ID')
    p.add_argument('--limit', type=int, default=100)
    p.add_argument('--cursor', help='Pagination cursor')
    p.set_defaults(func=cmd_block_children)

    # ── block-append ──
    p = sub.add_parser('block-append', help='Append blocks to a page or block')
    p.add_argument('id', help='Parent page/block ID')
    p.add_argument('--content', required=True, metavar='JSON',
                   help='Blocks as JSON array (or single block object)')
    p.set_defaults(func=cmd_block_append)

    # ── block-update ──
    p = sub.add_parser('block-update', help='Update a block\'s content')
    p.add_argument('id', help='Block ID')
    p.add_argument('--content', required=True, metavar='JSON',
                   help='Block update payload as JSON, e.g. {"paragraph":{"rich_text":[...]}}')
    p.set_defaults(func=cmd_block_update)

    # ── block-delete ──
    p = sub.add_parser('block-delete', help='Delete a block')
    p.add_argument('id', help='Block ID')
    p.set_defaults(func=cmd_block_delete)

    # ── db-get ──
    p = sub.add_parser('db-get', help='Get database schema and properties')
    p.add_argument('id', help='Database ID')
    p.set_defaults(func=cmd_db_get)

    # ── db-create ──
    p = sub.add_parser('db-create', help='Create a database inside a page')
    p.add_argument('--parent-page', required=True, metavar='ID')
    p.add_argument('--title', required=True)
    p.add_argument('--schema', metavar='JSON',
                   help='Properties schema as JSON object. Default: {"Name":{"title":{}}}')
    p.add_argument('--inline', action='store_true', help='Create as inline database')
    p.set_defaults(func=cmd_db_create)

    # ── db-update ──
    p = sub.add_parser('db-update', help='Update database title or schema')
    p.add_argument('id', help='Database ID')
    p.add_argument('--title')
    p.add_argument('--schema', metavar='JSON')
    p.set_defaults(func=cmd_db_update)

    # ── db-query ──
    p = sub.add_parser('db-query', help='Query database items with optional filter/sort')
    p.add_argument('id', help='Database ID')
    p.add_argument('--filter', metavar='JSON',
                   help='Filter object, e.g. {"property":"Status","status":{"equals":"Done"}}')
    p.add_argument('--sort', metavar='JSON',
                   help='Sort array or object, e.g. [{"property":"Name","direction":"ascending"}]')
    p.add_argument('--limit', type=int, default=50)
    p.add_argument('--cursor', help='Pagination cursor (has_more + next_cursor from previous call)')
    p.set_defaults(func=cmd_db_query)

    # ── db-item-create ──
    p = sub.add_parser('db-item-create', help='Create a new item (row) in a database')
    p.add_argument('id', help='Database ID')
    p.add_argument('--props', required=True, metavar='JSON',
                   help='Properties as JSON matching the database schema')
    p.add_argument('--content', metavar='JSON', help='Initial blocks as JSON array')
    p.add_argument('--icon', metavar='JSON')
    p.set_defaults(func=cmd_db_item_create)

    # ── comment-create ──
    p = sub.add_parser('comment-create', help='Add a comment to a page')
    p.add_argument('id', help='Page ID')
    p.add_argument('--text', required=True)
    p.set_defaults(func=cmd_comment_create)

    # ── comment-list ──
    p = sub.add_parser('comment-list', help='List comments on a page/block')
    p.add_argument('id', help='Page or block ID')
    p.set_defaults(func=cmd_comment_list)

    # ── users ──
    p = sub.add_parser('users', help='List all workspace users')
    p.set_defaults(func=cmd_users)

    # ── me ──
    p = sub.add_parser('me', help='Get info about the current integration bot')
    p.set_defaults(func=cmd_me)

    args = parser.parse_args()
    args.func(args)


if __name__ == '__main__':
    main()
