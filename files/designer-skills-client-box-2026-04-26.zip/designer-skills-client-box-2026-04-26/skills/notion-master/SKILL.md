---
name: notion-master
description: "Full Notion workspace management — pages, blocks, databases, search, comments. Use for any Notion operation: create, read, update, delete, move, query."
metadata:
  openclaw:
    emoji: "📝"
    always: false
    requires:
      bins: ["python3"]
---

# Notion Master

Full Notion API management via Python CLI. No external dependencies.

**Script:** `python3 ~/.openclaw/workspace/skills/notion-master/scripts/notion_master.py <command> [args]`

Shorthand alias for instructions below: `NOTION="python3 ~/.openclaw/workspace/skills/notion-master/scripts/notion_master.py"`

---

## Commands Reference

### 🔍 Search

```bash
# Search across entire workspace
$NOTION search "query text"
$NOTION search "query" --filter page       # pages only
$NOTION search "query" --filter database   # databases only
$NOTION search "query" --limit 10
```

---

### 📄 Pages

```bash
# Get page properties (title, parent, created_by, etc.)
$NOTION page-get <PAGE_ID>

# Create page inside another page
$NOTION page-create --parent-page <PAGE_ID> --title "Page title"

# Create page inside a database (with properties)
$NOTION page-create --parent-db <DB_ID> --title "Item name" \
  --props '{"Status":{"status":{"name":"In progress"}}}'

# Create page with initial content blocks
$NOTION page-create --parent-page <PAGE_ID> --title "New doc" \
  --content '[{"object":"block","type":"paragraph","paragraph":{"rich_text":[{"type":"text","text":{"content":"Hello!"}}]}}]'

# Add emoji icon and cover
$NOTION page-create --parent-page <PAGE_ID> --title "Doc" \
  --icon '{"type":"emoji","emoji":"🔥"}' \
  --cover '{"type":"external","external":{"url":"https://images.unsplash.com/..."}}'

# Update page title
$NOTION page-update <PAGE_ID> --title "New title"

# Update page properties (e.g. in a database)
$NOTION page-update <PAGE_ID> --props '{"Status":{"status":{"name":"Done"}}}'

# Update icon
$NOTION page-update <PAGE_ID> --icon '{"type":"emoji","emoji":"✅"}'

# Archive page (soft delete)
$NOTION page-archive <PAGE_ID>

# Restore archived page
$NOTION page-unarchive <PAGE_ID>

# Get page content (blocks)
$NOTION page-content <PAGE_ID>
$NOTION page-content <PAGE_ID> --limit 50 --cursor <NEXT_CURSOR>

# Move page to another page
$NOTION page-move <PAGE_ID> --to-page <TARGET_PAGE_ID>

# Move page into a database
$NOTION page-move <PAGE_ID> --to-db <TARGET_DB_ID>
```

---

### 🧱 Blocks

```bash
# Get a single block
$NOTION block-get <BLOCK_ID>

# Get children of a block or page
$NOTION block-children <BLOCK_ID>

# Append blocks to a page or block
$NOTION block-append <PAGE_OR_BLOCK_ID> --content '<JSON_ARRAY>'

# Update block content
$NOTION block-update <BLOCK_ID> --content '{"paragraph":{"rich_text":[{"type":"text","text":{"content":"updated text"}}]}}'

# Delete a block
$NOTION block-delete <BLOCK_ID>
```

#### Block Type Reference

Use these as elements of the `--content '[...]'` array:

**Paragraph**
```json
{"object":"block","type":"paragraph","paragraph":{"rich_text":[{"type":"text","text":{"content":"Text here"}}]}}
```

**Headings**
```json
{"object":"block","type":"heading_1","heading_1":{"rich_text":[{"type":"text","text":{"content":"H1 title"}}]}}
{"object":"block","type":"heading_2","heading_2":{"rich_text":[{"type":"text","text":{"content":"H2 title"}}]}}
{"object":"block","type":"heading_3","heading_3":{"rich_text":[{"type":"text","text":{"content":"H3 title"}}]}}
```

**Lists**
```json
{"object":"block","type":"bulleted_list_item","bulleted_list_item":{"rich_text":[{"type":"text","text":{"content":"Item"}}]}}
{"object":"block","type":"numbered_list_item","numbered_list_item":{"rich_text":[{"type":"text","text":{"content":"Item"}}]}}
```

**To-do**
```json
{"object":"block","type":"to_do","to_do":{"rich_text":[{"type":"text","text":{"content":"Task"}}],"checked":false}}
```

**Toggle**
```json
{"object":"block","type":"toggle","toggle":{"rich_text":[{"type":"text","text":{"content":"Toggle header"}}],"children":[{"object":"block","type":"paragraph","paragraph":{"rich_text":[{"type":"text","text":{"content":"Hidden content"}}]}}]}}
```

**Code block**
```json
{"object":"block","type":"code","code":{"rich_text":[{"type":"text","text":{"content":"print('hello')"}}],"language":"python"}}
```
Languages: `python`, `javascript`, `typescript`, `bash`, `sql`, `json`, `markdown`, `plain text`, etc.

**Quote**
```json
{"object":"block","type":"quote","quote":{"rich_text":[{"type":"text","text":{"content":"Quote text"}}]}}
```

**Callout**
```json
{"object":"block","type":"callout","callout":{"rich_text":[{"type":"text","text":{"content":"Note text"}}],"icon":{"type":"emoji","emoji":"💡"}}}
```

**Divider**
```json
{"object":"block","type":"divider","divider":{}}
```

**Image (external URL)**
```json
{"object":"block","type":"image","image":{"type":"external","external":{"url":"https://example.com/image.png"}}}
```

**Bookmark / link**
```json
{"object":"block","type":"bookmark","bookmark":{"url":"https://example.com"}}
```

**Bold / italic text in rich_text**
```json
{"type":"text","text":{"content":"bold text"},"annotations":{"bold":true}}
{"type":"text","text":{"content":"italic text"},"annotations":{"italic":true}}
{"type":"text","text":{"content":"colored"},"annotations":{"color":"red"}}
```
Colors: `red`, `blue`, `green`, `yellow`, `orange`, `pink`, `purple`, `gray`, `brown`, and `*_background` variants.

---

### 🗄️ Databases

```bash
# Get database schema (properties definition)
$NOTION db-get <DB_ID>

# Create a new database in a page
$NOTION db-create --parent-page <PAGE_ID> --title "My DB"

# Create database with custom schema
$NOTION db-create --parent-page <PAGE_ID> --title "Tasks" \
  --schema '{"Name":{"title":{}},"Status":{"status":{}},"Due":{"date":{}},"Tags":{"multi_select":{}}}'

# Create as inline database (table view in page)
$NOTION db-create --parent-page <PAGE_ID> --title "Table" --inline

# Update database title or schema
$NOTION db-update <DB_ID> --title "New name"
$NOTION db-update <DB_ID> --schema '{"Priority":{"select":{"options":[{"name":"High","color":"red"},{"name":"Low","color":"green"}]}}}'

# Query all items
$NOTION db-query <DB_ID>

# Query with filter
$NOTION db-query <DB_ID> --filter '{"property":"Status","status":{"equals":"Done"}}'

# Query with AND filter
$NOTION db-query <DB_ID> --filter '{"and":[{"property":"Status","status":{"equals":"In progress"}},{"property":"Priority","select":{"equals":"High"}}]}'

# Query with sort
$NOTION db-query <DB_ID> --sort '[{"property":"Due","direction":"ascending"}]'

# Pagination
$NOTION db-query <DB_ID> --limit 10
$NOTION db-query <DB_ID> --limit 10 --cursor <NEXT_CURSOR>
```

#### Database Property Types Reference

Use in `--schema` for `db-create` / `db-update`:
```json
{
  "Name":       {"title": {}},
  "Status":     {"status": {}},
  "Select":     {"select": {"options": [{"name": "Option A", "color": "blue"}]}},
  "MultiTag":   {"multi_select": {"options": [{"name": "Tag1"}, {"name": "Tag2"}]}},
  "Date":       {"date": {}},
  "Checkbox":   {"checkbox": {}},
  "Number":     {"number": {"format": "number"}},
  "URL":        {"url": {}},
  "Email":      {"email": {}},
  "Phone":      {"phone_number": {}},
  "Text":       {"rich_text": {}},
  "Person":     {"people": {}},
  "File":       {"files": {}},
  "Relation":   {"relation": {"database_id": "<OTHER_DB_ID>"}},
  "Formula":    {"formula": {"expression": "prop(\"Name\")"}},
  "Rollup":     {"rollup": {"rollup_property_name": "...", "relation_property_name": "...", "function": "count"}}
}
```

### 📝 Create database item

```bash
# Minimal (title only)
$NOTION db-item-create <DB_ID> --props '{"Name":{"title":[{"type":"text","text":{"content":"Item name"}}]}}'

# With status and date
$NOTION db-item-create <DB_ID> --props '{
  "Name":   {"title":  [{"type":"text","text":{"content":"Task name"}}]},
  "Status": {"status": {"name":"In progress"}},
  "Due":    {"date":   {"start":"2026-03-01"}},
  "Tags":   {"multi_select":[{"name":"AI"},{"name":"важное"}]}
}'

# With initial page content
$NOTION db-item-create <DB_ID> \
  --props '{"Name":{"title":[{"type":"text","text":{"content":"New task"}}]}}' \
  --content '[{"object":"block","type":"paragraph","paragraph":{"rich_text":[{"type":"text","text":{"content":"Task description"}}]}}]'
```

---

### 💬 Comments

```bash
# Add comment to a page
$NOTION comment-create <PAGE_ID> --text "Comment text"

# List comments on a page
$NOTION comment-list <PAGE_ID>
```

---

### 👥 Users

```bash
# List all workspace users
$NOTION users

# Get info about this integration bot
$NOTION me
```

---

## Common Workflows

### Read full page content
```bash
# 1. Get page properties
$NOTION page-get <PAGE_ID>
# 2. Get blocks
$NOTION page-content <PAGE_ID>
# 3. If has_more=true, paginate
$NOTION page-content <PAGE_ID> --cursor <NEXT_CURSOR>
```

### Add content to existing page
```bash
$NOTION block-append <PAGE_ID> --content '[
  {"object":"block","type":"heading_2","heading_2":{"rich_text":[{"type":"text","text":{"content":"New Section"}}]}},
  {"object":"block","type":"paragraph","paragraph":{"rich_text":[{"type":"text","text":{"content":"Content here"}}]}}
]'
```

### Query database and update items
```bash
# Find items with status "todo"
$NOTION db-query <DB_ID> --filter '{"property":"Status","status":{"equals":"todo"}}'
# Update item status (use page id from query result)
$NOTION page-update <ITEM_PAGE_ID> --props '{"Status":{"status":{"name":"Done"}}}'
```

### Move page between databases
```bash
$NOTION page-move <PAGE_ID> --to-db <TARGET_DB_ID>
```

---

## Tips

- IDs: use the bare UUID form (`abc123...`), not the full URL
- To get a page's ID: from URL `notion.so/workspace/PageName-<ID>` → copy the last part
- `page-content` returns blocks; to get nested (children of children), call `block-children` on each block with `has_children: true`
- All output is JSON — pipe to `| python3 -m json.tool` or `| jq` for readability
- On error: returns `{"error": "...", "code": "...", "status": <HTTP_code>}` and exits 1

## Known IDs

Подставь сюда свои page/database IDs после подключения клиента к Notion.
