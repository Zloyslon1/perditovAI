---
name: video-editor
description: "Автомонтаж видео: субтитры, нарезка футажей, полная сборка → FCPXML для Final Cut Pro"
---

# Video Editor — автомонтаж

Набор CLI-инструментов для автоматизации видеомонтажа. Результат — FCPXML файл для импорта в Final Cut Pro.

## Инструменты

### auto-subs
Автоматические субтитры. Транскрибирует аудио → генерирует субтитры в FCPXML + SRT.

```bash
node skills/video-gen/video-editor/src/auto-subs.js input.mp4
```

**Опции:**
- `--lang ru` — язык (по умолчанию: ru)
- `--max-chars 35` — макс символов в строке
- `--style bold` — стиль субтитров

### auto-cut
Автомонтаж: футажи + аудио → FCPXML таймлайн. Подбирает кадры по описанию.

```bash
node skills/video-gen/video-editor/src/auto-cut.js --footage ./footage --audio voiceover.mp3
```

**Требования:**
- Папка с футажами (mp4/mov/mts)
- Файл `footage.md` с описаниями каждого файла
- Аудиодорожка (войсовер)

### auto-assemble
Полная сборка: объединяет auto-cut + auto-subs. Футажи + аудио → FCPXML с субтитрами.

```bash
node skills/video-gen/video-editor/src/auto-assemble.js --footage ./footage --audio voiceover.mp3
```

## Требования
- Node.js 18+
- ffmpeg (для анализа видео)
- Whisper CLI (для транскрипции)
- Final Cut Pro (для импорта FCPXML)

## Установка
```bash
cd skills/video-gen/video-editor && npm link
```
После этого команды `auto-subs`, `auto-cut`, `auto-assemble` доступны глобально.

## Пайплайн
1. Запиши войсовер (или сгенерируй через TTS)
2. Сними/собери папку футажей + опиши в footage.md
3. `auto-assemble` → получи FCPXML
4. Импортируй в Final Cut Pro → рендер

*Video Editor v1.1.0*
