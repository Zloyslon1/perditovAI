---
name: video-gen
description: Генерация видео — Veo, HeyGen аватары, таймлапсы, видеоредактор
metadata:
  {
    "openclaw": { "emoji": "🎥" }
  }
---

# Video Gen — Генерация видео

AI-генерация видео: текст-в-видео через Veo, AI-аватары через HeyGen, таймлапсы, автоматизация монтажа.

## Context Loading (обязательно перед работой)
1. Читай `brand/voice-style.md` → тон и стиль
2. Читай `brand/audience.md` → для кого
3. Читай `learning/approved-patterns.md` → что работает
4. Читай `learning/rejected-patterns.md` → чего избегать
5. Если есть `brand/personal-dna.md` → подтягивай личность

## File Router

| Задача | Подпапка | Что там |
|--------|----------|---------|
| Генерация видео из текста (Veo 3.1) | `{baseDir}/veo/` | Текст-в-видео, анимация изображений, расширение |
| AI-аватары с озвучкой (HeyGen) | `{baseDir}/heygen/` | Скрипты для аватаров, motion промпты, озвучка |
| Таймлапсы | `{baseDir}/timelapse/` | Пайплайн: keyframes → approval → video clips |
| Видеоредактор (Final Cut Pro) | `{baseDir}/video-editor/` | Автосубтитры, автомонтаж, сборка FCPXML |

## Workflow

### Veo (текст → видео)
1. Составь промпт как режиссёр (направляй сцену, не описывай)
2. Выбери режим: текст-в-видео / анимация изображения / расширение
3. Сгенерируй через API
4. Итерируй по результату

### HeyGen (AI-аватары)
1. Напиши скрипт с правилами HeyGen-озвучки
2. Создай motion промпт для фото (если нужно)
3. Загрузи в HeyGen

### Timelapse
1. Определи концепт (что трансформируется)
2. Сгенерируй keyframes через Nano Banana
3. Утверди кадры
4. Сгенерируй видео-переходы через Veo

### Video Editor
1. `auto-subs` — автосубтитры (Whisper → FCPXML)
2. `auto-cut` — автомонтаж
3. `auto-assemble` — сборка проекта

## Ключевые файлы по подпапкам

### veo/
- `references/prompt-library.md` — библиотека промптов
- `references/` — дополнительные материалы
- `scripts/` — скрипты для генерации

### heygen/
- `heygen-rules.md` — правила озвучки для HeyGen
- `heygen-motion.md` — motion промпты

### video-editor/
- `package.json` — зависимости скриптов
