---
name: kie-image
description: Generate images through KIE AI with GPT-Image 2. Use when the user explicitly asks for KIE, KIE AI, kie.ai, GPT-Image 2, gpt-image-2, or says the image should be generated through KIE instead of LaoZhang/Nano Banana. Best for prompt-based text-to-image generation where KIE's async API is required.
---

# KIE Image

Use this skill when the user wants image generation specifically through **KIE** and especially through **GPT-Image 2**.

## Default route

For this skill, default to **GPT-Image 2 text-to-image via KIE**.

Do **not** route this through OpenClaw `image_generate`. KIE uses its own async task API.

## Commands

Use the bundled script:

```bash
python3 ./scripts/kie_image.py credits
python3 ./scripts/kie_image.py gpt2 --prompt "Brutalist cyberpunk poster with lime accent"
```

## Main parameters

### Required
- `--prompt` — text prompt in English when possible

### Optional
- `--aspect-ratio auto|1:1|9:16|16:9|4:3|3:4`
- `--resolution 1K|2K|4K`
- `--poll-seconds <int>`
- `--timeout-seconds <int>`
- `--output-root <path>`

## Guardrails

- If `aspect-ratio=auto`, use `resolution=1K` only.
- If `aspect-ratio=1:1`, do **not** request `4K`.
- Save results locally immediately because result URLs can expire.
- For production integrations, prefer callback URL. For chat work, polling is fine.

## Workflow

1. Confirm the user really wants **KIE**.
2. Write one precise visual prompt.
3. Run `credits` if balance is relevant.
4. Run `gpt2` generation.
5. Wait for local saved files.
6. If the user asked for the actual image in chat, send the saved file.
7. If the user asked for setup/integration only, report the exact command and result.

## Output location

Generated files are saved to:

```text
~/.openclaw/generated/kie-gpt-image-2/<taskId>/
```

The script prints JSON with:
- `taskId`
- `saved`
- `sourceUrls`
- `status`

## References

If you need exact API shapes, read:
- `references/api_reference.md`

## Example

```bash
python3 ./scripts/kie_image.py gpt2 \
  --prompt "A premium dark brutalist Telegram promo poster, graphite background, acid lime accent, sharp typography, cinematic lighting" \
  --aspect-ratio 3:4 \
  --resolution 2K
```
