#!/usr/bin/env python3
import argparse
import json
import mimetypes
import os
import pathlib
import sys
import time
from urllib.parse import urlparse

import requests

BASE_URL = "https://api.kie.ai"
CONFIG_PATH = os.path.expanduser("~/.openclaw/openclaw.json")
DEFAULT_OUTPUT_ROOT = os.path.expanduser("~/.openclaw/generated/kie-gpt-image-2")
MODEL_NAME = "gpt-image-2-text-to-image"
TASK_ENDPOINT = "/api/v1/jobs/createTask"
TASK_INFO_ENDPOINT = "/api/v1/jobs/recordInfo"
CREDITS_ENDPOINT = "/api/v1/chat/credit"


def load_api_key() -> str:
    key = os.getenv("KIE_API_KEY")
    if key:
        return key
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("env", {}).get("vars", {}).get("KIE_API_KEY", "")
    except Exception:
        return ""


API_KEY = load_api_key()


def die(message: str, code: int = 1):
    print(json.dumps({"ok": False, "error": message}, ensure_ascii=False))
    sys.exit(code)


if not API_KEY:
    die("KIE_API_KEY not found in env or ~/.openclaw/openclaw.json")


def api_headers(json_body: bool = False):
    headers = {"Authorization": f"Bearer {API_KEY}"}
    if json_body:
        headers["Content-Type"] = "application/json"
    return headers


def request_json(method: str, path: str, *, params=None, json_body=None, timeout=120):
    url = f"{BASE_URL}{path}"
    response = requests.request(
        method,
        url,
        headers=api_headers(json_body is not None),
        params=params,
        json=json_body,
        timeout=timeout,
    )
    try:
        data = response.json()
    except Exception:
        raise RuntimeError(f"Non-JSON response from {url}: HTTP {response.status_code} {response.text[:500]}")
    if not response.ok:
        raise RuntimeError(f"HTTP {response.status_code} from {url}: {data}")
    if data.get("code") != 200:
        raise RuntimeError(f"API error from {url}: {data}")
    return data


def get_credits():
    data = request_json("GET", CREDITS_ENDPOINT, timeout=30)
    return data.get("data")


def validate_gpt2_args(args):
    if args.aspect_ratio == "auto" and args.resolution != "1K":
        raise ValueError("KIE GPT-Image 2 allows aspect_ratio=auto only with resolution=1K")
    if args.aspect_ratio == "1:1" and args.resolution == "4K":
        raise ValueError("KIE GPT-Image 2 does not allow 4K with aspect_ratio=1:1")


def submit_gpt2(args):
    validate_gpt2_args(args)
    payload = {
        "model": MODEL_NAME,
        "input": {
            "prompt": args.prompt,
            "aspect_ratio": args.aspect_ratio,
            "resolution": args.resolution,
        },
    }
    if args.callback_url:
        payload["callBackUrl"] = args.callback_url
    data = request_json("POST", TASK_ENDPOINT, json_body=payload, timeout=60)
    return data["data"]["taskId"]


def get_task_status(task_id: str):
    data = request_json("GET", TASK_INFO_ENDPOINT, params={"taskId": task_id}, timeout=60)
    return data["data"]


def parse_result_urls(status: dict):
    raw = status.get("resultJson")
    if not raw:
        return []
    if isinstance(raw, dict):
        parsed = raw
    else:
        parsed = json.loads(raw)
    urls = parsed.get("resultUrls") or []
    if isinstance(urls, list):
        return urls
    return []


def get_download_url(url: str):
    try:
        data = request_json("POST", "/api/v1/common/download-url", json_body={"url": url}, timeout=60)
        return data.get("data") or url
    except Exception:
        return url


def detect_extension(url: str, response: requests.Response, fallback: str = ".bin"):
    path = urlparse(url).path
    ext = pathlib.Path(path).suffix
    if ext:
        return ext
    content_type = response.headers.get("Content-Type", "").split(";")[0].strip()
    guessed = mimetypes.guess_extension(content_type) if content_type else None
    return guessed or fallback


def download_file(url: str, output_dir: str, index: int):
    os.makedirs(output_dir, exist_ok=True)
    real_url = get_download_url(url)
    response = requests.get(real_url, timeout=120)
    response.raise_for_status()
    ext = detect_extension(real_url, response, fallback=".jpg")
    filename = f"image-{index}{ext}"
    path = os.path.join(output_dir, filename)
    with open(path, "wb") as f:
        f.write(response.content)
    return path, real_url


def wait_for_task(task_id: str, poll_seconds: int, timeout_seconds: int):
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        status = get_task_status(task_id)
        state = status.get("state")
        if state == "success":
            return status, parse_result_urls(status)
        if state == "fail":
            code = status.get("failCode") or "unknown"
            msg = status.get("failMsg") or "Task failed"
            raise RuntimeError(f"Task failed ({code}): {msg}")
        time.sleep(poll_seconds)
    raise TimeoutError(f"Timed out waiting for task {task_id}")


def command_credits(_args):
    credits = get_credits()
    print(json.dumps({"ok": True, "credits": credits}, ensure_ascii=False, indent=2))


def command_gpt2(args):
    task_id = submit_gpt2(args)
    status, urls = wait_for_task(task_id, args.poll_seconds, args.timeout_seconds)
    output_dir = os.path.join(args.output_root, task_id)
    saved = []
    resolved_urls = []
    for i, url in enumerate(urls, start=1):
        path, real_url = download_file(url, output_dir, i)
        saved.append(path)
        resolved_urls.append(real_url)
    print(json.dumps({
        "ok": True,
        "provider": "kie",
        "api": MODEL_NAME,
        "taskId": task_id,
        "saved": saved,
        "sourceUrls": urls,
        "downloadUrls": resolved_urls,
        "status": status,
    }, ensure_ascii=False, indent=2))


def build_parser():
    parser = argparse.ArgumentParser(description="KIE GPT-Image 2 helper")
    sub = parser.add_subparsers(dest="command", required=True)

    credits = sub.add_parser("credits", help="Check KIE credits")
    credits.set_defaults(func=command_credits)

    gpt2 = sub.add_parser("gpt2", help="Generate via KIE GPT-Image 2 text-to-image API")
    gpt2.add_argument("--prompt", required=True)
    gpt2.add_argument("--aspect-ratio", default="auto", choices=["auto", "1:1", "9:16", "16:9", "4:3", "3:4"])
    gpt2.add_argument("--resolution", default="1K", choices=["1K", "2K", "4K"])
    gpt2.add_argument("--callback-url")
    gpt2.add_argument("--poll-seconds", type=int, default=3)
    gpt2.add_argument("--timeout-seconds", type=int, default=600)
    gpt2.add_argument("--output-root", default=DEFAULT_OUTPUT_ROOT)
    gpt2.set_defaults(func=command_gpt2)

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    try:
        args.func(args)
    except KeyboardInterrupt:
        die("Interrupted", 130)
    except Exception as e:
        die(str(e), 1)


if __name__ == "__main__":
    main()
