# KIE GPT-Image 2 API Reference

## Base
- Base URL: `https://api.kie.ai`
- Auth: `Authorization: Bearer <KIE_API_KEY>`

## Credits
`GET /api/v1/chat/credit`

Success shape:

```json
{
  "code": 200,
  "msg": "success",
  "data": 100
}
```

## Create task
`POST /api/v1/jobs/createTask`

Body:

```json
{
  "model": "gpt-image-2-text-to-image",
  "input": {
    "prompt": "A cinematic night city poster with neon reflections on a rainy street.",
    "aspect_ratio": "3:4",
    "resolution": "2K"
  }
}
```

### Allowed values

#### `model`
- `gpt-image-2-text-to-image`

#### `input.aspect_ratio`
- `auto`
- `1:1`
- `9:16`
- `16:9`
- `4:3`
- `3:4`

#### `input.resolution`
- `1K`
- `2K`
- `4K`

## Important constraints
- `aspect_ratio=auto` supports only `1K`
- `aspect_ratio=1:1` cannot be used with `4K`
- Prompt max length: `20000`

## Create task response

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "taskId": "task_gptimage_1765180586443"
  }
}
```

## Poll task
`GET /api/v1/jobs/recordInfo?taskId=<taskId>`

### Task states
- `waiting`
- `queuing`
- `generating`
- `success`
- `fail`

Success response contains `resultJson` as a JSON string:

```json
{
  "resultUrls": [
    "https://.../generated-image.jpg"
  ]
}
```

## Recommended polling
- Start at 3 seconds
- Stop after 10-15 minutes
- Download outputs immediately

## Local script mapping
- `credits` → `GET /api/v1/chat/credit`
- `gpt2` → `POST /api/v1/jobs/createTask` + poll `GET /api/v1/jobs/recordInfo`
