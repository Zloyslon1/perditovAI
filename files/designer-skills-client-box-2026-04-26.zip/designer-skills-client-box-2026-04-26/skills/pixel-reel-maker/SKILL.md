---
name: pixel-reel-maker
description: "Генерация pixel art lo-fi Reels/Shorts. Полный пайплайн: сценарий → озвучка → таймстемпы → картинки → Veo анимация → субтитры → финальное видео. Активируется на: 'сделай рилс', 'генерируй видео', 'pixel art видео', 'создай Reels', 'смонтируй ролик', 'pixel reel'."
---

# Pixel Reel Maker

Полный пайплайн генерации вертикальных видео (Reels/Shorts/TikTok) в pixel art стиле.

## Pipeline

```
Сценарий (текст)
  → ElevenLabs озвучка (ваш voice preset)
  → Groq Whisper таймстемпы по словам
  → Gemini 3 Pro pixel art сцены (через LaoZhang)
  → Veo 3.1 анимация каждой сцены (через LaoZhang)
  → Растяжка клипов до длительности аудио-сегмента
  → Конкатенация видео
  → PIL субтитры по одному слову, по центру
  → Финальная сборка: видео + аудио + субтитры
  → final.mp4 (1080×1920, 25fps)
```

## API Keys (уже в env)

| Переменная | Сервис | Назначение |
|---|---|---|
| `LAOZHANG_API_KEY` | LaoZhang | Gemini картинки + Veo видео |
| `ELEVENLABS_API_KEY` | ElevenLabs | Озвучка |
| `ELEVENLABS_VOICE_ID_RU` | ElevenLabs | Ваш RU voice ID |
| `ELEVENLABS_VOICE_ID_EN` | ElevenLabs | Ваш EN voice ID |
| `GROQ_API_KEY` | Groq | Whisper таймстемпы |

## Quick Start

### 1. Подготовка

```bash
# Создать рабочую папку
WORKDIR=~/openclaw-factory/agents/designer/pixel-reel-work
mkdir -p $WORKDIR/scene_images $WORKDIR/veo_clips $WORKDIR/frames
```

### 2. Озвучка (ElevenLabs)

```bash
curl -s --max-time 120 "https://api.elevenlabs.io/v1/text-to-speech/$ELEVENLABS_VOICE_ID_RU" \
  -H "xi-api-key: $ELEVENLABS_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "ТЕКСТ СЦЕНАРИЯ",
    "model_id": "eleven_multilingual_v2",
    "voice_settings": {"stability": 0.5, "similarity_boost": 0.8, "style": 0.3}
  }' -o $WORKDIR/voiceover.mp3
```

### 3. Таймстемпы (Groq Whisper)

```bash
curl -s --max-time 60 "https://api.groq.com/openai/v1/audio/transcriptions" \
  -H "Authorization: Bearer $GROQ_API_KEY" \
  -F "file=@$WORKDIR/voiceover.mp3" \
  -F "model=whisper-large-v3" \
  -F "response_format=verbose_json" \
  -F "timestamp_granularities[]=word" \
  -F "language=ru" \
  -o $WORKDIR/timestamps.json
```

### 4. Pixel Art сцены (LaoZhang Gemini)

```bash
# Для каждой сцены — с референсом лица или без
curl -s --max-time 120 \
  "https://api.laozhang.ai/v1beta/models/gemini-3-pro-image-preview:generateContent" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $LAOZHANG_API_KEY" \
  -d '{
    "contents": [{"parts": [
      {"text": "Generate a pixel art image in 9:16 aspect ratio, lo-fi retro 16-bit style. ОПИСАНИЕ СЦЕНЫ"}
    ]}],
    "generationConfig": {
      "responseModalities": ["IMAGE"],
      "imageConfig": {"aspectRatio": "9:16"}
    }
  }'
```

**С референсом лица** — добавить `inlineData` part перед текстом:
```json
{"inlineData": {"mimeType": "image/jpeg", "data": "BASE64_ФОТО"}}
```

Референс: `<PATH_TO_FACE_REFERENCE_IMAGE>`

### 5. Veo 3.1 анимация (LaoZhang)

```bash
# Запуск генерации
curl -s "https://api.laozhang.ai/v1/video/generations" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $LAOZHANG_API_KEY" \
  -d '{
    "model": "veo-3.1-relaxed",
    "prompt": "Pixel art lo-fi retro 16-bit animation, 9:16 vertical. ОПИСАНИЕ СЦЕНЫ",
    "n": 1,
    "size": "1080x1920"
  }'
# Ответ: {"id": "video_xxx", "status": "queued"}

# Проверка статуса
curl -s "https://api.laozhang.ai/v1/video/generations/VIDEO_ID" \
  -H "Authorization: Bearer $LAOZHANG_API_KEY"
# Когда status=completed → video_url содержит ссылку на mp4
```

**Модели (от дешёвой к дорогой):**
- `veo-3.1-relaxed` — самый дешёвый, медленнее
- `veo-3.1-fast` — быстрый (~80 сек)
- `veo-3.1` — стандартный
- `veo-3.1-4k` — 4K качество

Каждый клип = 8 секунд. Для более длинных сцен — замедляем через `setpts`.

### 6. Сборка финального видео

```bash
python3 scripts/assemble_reel.py \
  --workdir $WORKDIR \
  --scenes "0:10,10:24,24:36,36:50,50:63,63:73" \
  --output $WORKDIR/final.mp4
```

Или вручную через `scripts/assemble_reel.py` (см. скрипт).

## Ключевые правила

1. **Субтитры** — по ОДНОМУ слову, по центру экрана, шрифт Impact 80px, белый с чёрным контуром
2. **Модель Veo** — использовать `veo-3.1-relaxed` (самый дешёвый) если не просят иначе
3. **Промпты сцен** — всегда начинать с "Pixel art lo-fi retro 16-bit animation, 9:16 vertical."
4. **Референс лица** — если нужен конкретный человек/персонаж в кадре, использовать `anton-front.jpg`
5. **Растяжка клипов** — Veo даёт 8 сек, аудио-сегмент может быть длиннее → `setpts=FACTOR*PTS`
6. **Без libass/drawtext** — на текущем ffmpeg нет этих фильтров, субтитры через PIL (Pillow)

## Голоса ElevenLabs

Используй свои voice IDs в `ELEVENLABS_VOICE_ID_RU` и `ELEVENLABS_VOICE_ID_EN`.
Не вшивай клиентские voice IDs в skill.

## Стоимость одного ролика (~60 сек)

| Компонент | Цена |
|---|---|
| ElevenLabs озвучка | ~$0.15 |
| Groq Whisper | ~$0.01 |
| 6 Gemini картинок | ~$0.30 |
| 6 Veo клипов (relaxed) | ~$1.50 |
| **Итого** | **~$2** |
