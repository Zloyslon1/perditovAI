#!/usr/bin/env python3
"""
Pixel Reel Maker — Scene Generator
Генерирует pixel art сцены через LaoZhang Gemini и Veo анимации.

Usage:
    python3 generate_scenes.py --workdir /path/to/work --prompts prompts.json [--face-ref /path/to/face.jpg]
    
prompts.json format:
[
    {"scene": 1, "image_prompt": "...", "video_prompt": "...", "start": 0, "end": 10},
    ...
]
"""

import argparse, json, base64, time, os, sys, requests

def generate_image(prompt, api_key, face_ref_b64=None, output_path=None):
    """Generate pixel art image via LaoZhang Gemini"""
    parts = []
    if face_ref_b64:
        parts.append({"inlineData": {"mimeType": "image/jpeg", "data": face_ref_b64}})
    parts.append({"text": f"Generate a pixel art image in 9:16 aspect ratio, lo-fi retro 16-bit style. {prompt}"})
    
    resp = requests.post(
        "https://api.laozhang.ai/v1beta/models/gemini-3-pro-image-preview:generateContent",
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
        json={
            "contents": [{"parts": parts}],
            "generationConfig": {"responseModalities": ["IMAGE"], "imageConfig": {"aspectRatio": "9:16"}}
        },
        timeout=120
    )
    data = resp.json()
    if "error" in data:
        print(f"  ERROR: {data['error']}")
        return False
    
    for part in data["candidates"][0]["content"]["parts"]:
        if "inlineData" in part:
            img_bytes = base64.b64decode(part["inlineData"]["data"])
            with open(output_path, "wb") as f:
                f.write(img_bytes)
            return True
    return False

def generate_video(prompt, api_key, model="veo-3.1-relaxed"):
    """Launch Veo video generation, return job ID"""
    resp = requests.post(
        "https://api.laozhang.ai/v1/video/generations",
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
        json={"model": model, "prompt": prompt, "n": 1, "size": "1080x1920"},
        timeout=30
    )
    data = resp.json()
    return data.get("id"), data.get("status")

def poll_video(job_id, api_key, output_path, max_wait=600):
    """Poll until video is ready, download it"""
    start = time.time()
    while time.time() - start < max_wait:
        resp = requests.get(
            f"https://api.laozhang.ai/v1/video/generations/{job_id}",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=15
        )
        data = resp.json()
        status = data.get("status", "unknown")
        progress = data.get("progress", 0)
        
        if status == "completed":
            url = data.get("video_url") or data.get("url") or data.get("result_url")
            r = requests.get(url, timeout=60)
            with open(output_path, "wb") as f:
                f.write(r.content)
            return True
        elif status == "failed":
            print(f"  FAILED: {data.get('error')}")
            return False
        
        time.sleep(15)
    return False

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workdir", required=True)
    parser.add_argument("--prompts", required=True, help="JSON file with scene prompts")
    parser.add_argument("--face-ref", default=None, help="Path to face reference photo")
    parser.add_argument("--veo-model", default="veo-3.1-relaxed")
    parser.add_argument("--skip-images", action="store_true")
    parser.add_argument("--skip-videos", action="store_true")
    args = parser.parse_args()

    api_key = os.environ.get("LAOZHANG_API_KEY")
    if not api_key:
        print("ERROR: LAOZHANG_API_KEY not set")
        sys.exit(1)

    with open(args.prompts) as f:
        scenes = json.load(f)

    face_b64 = None
    if args.face_ref:
        with open(args.face_ref, "rb") as f:
            face_b64 = base64.b64encode(f.read()).decode()
        print(f"Face ref loaded: {args.face_ref}")

    os.makedirs(os.path.join(args.workdir, "scene_images"), exist_ok=True)

    # Generate images
    if not args.skip_images:
        print("\n=== GENERATING IMAGES ===")
        for s in scenes:
            i = s["scene"]
            out = os.path.join(args.workdir, "scene_images", f"scene_{i:02d}.png")
            print(f"Scene {i}: generating image...")
            ok = generate_image(s["image_prompt"], api_key, face_b64, out)
            print(f"  {'✅' if ok else '❌'} {out}")
            time.sleep(2)

    # Generate videos
    if not args.skip_videos:
        print("\n=== GENERATING VIDEOS ===")
        jobs = []
        for s in scenes:
            i = s["scene"]
            prompt = f"Pixel art lo-fi retro 16-bit animation, 9:16 vertical. {s['video_prompt']}"
            job_id, status = generate_video(prompt, api_key, args.veo_model)
            print(f"Scene {i}: {job_id} → {status}")
            jobs.append({"scene": i, "id": job_id})
            time.sleep(1)

        print("\n=== DOWNLOADING VIDEOS ===")
        for job in jobs:
            i = job["scene"]
            out = os.path.join(args.workdir, f"veo_scene_{i:02d}.mp4")
            print(f"Scene {i}: polling...")
            ok = poll_video(job["id"], api_key, out)
            size = os.path.getsize(out) if ok else 0
            print(f"  {'✅' if ok else '❌'} {size//1024}KB")

    print("\n✅ All scenes generated")

if __name__ == "__main__":
    main()
