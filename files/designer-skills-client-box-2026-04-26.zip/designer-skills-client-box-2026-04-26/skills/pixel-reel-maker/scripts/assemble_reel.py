#!/usr/bin/env python3
"""
Pixel Reel Maker — Assembly Script
Собирает финальное видео из Veo клипов + озвучки + субтитров по словам.

Usage:
    python3 assemble_reel.py --workdir /path/to/work --output /path/to/final.mp4

Expected files in workdir:
    voiceover.mp3          — озвучка
    timestamps.json        — Groq Whisper timestamps (verbose_json with words)
    veo_scene_01.mp4 ...   — Veo клипы (8 сек каждый)

Scene timing is auto-calculated from audio duration / number of clips,
or pass --scenes "0:10,10:24,24:36" for manual timings.
"""

import argparse, json, subprocess, os, sys
from PIL import Image, ImageDraw, ImageFont

def find_font():
    """Find a good bold font on macOS"""
    candidates = [
        "/System/Library/Fonts/Supplemental/Impact.ttf",
        "/System/Library/Fonts/Helvetica.ttc",
        "/Library/Fonts/Arial Bold.ttf",
        "/System/Library/Fonts/SFCompactDisplay-Bold.otf",
        "/System/Library/Fonts/SFNS.ttf",
    ]
    for fp in candidates:
        if os.path.exists(fp):
            return fp
    return None

def main():
    parser = argparse.ArgumentParser(description="Assemble Pixel Reel")
    parser.add_argument("--workdir", required=True, help="Working directory")
    parser.add_argument("--output", default=None, help="Output file path")
    parser.add_argument("--scenes", default=None, help="Scene timings: '0:10,10:24,...'")
    parser.add_argument("--fps", type=int, default=25, help="FPS (default 25)")
    parser.add_argument("--font-size", type=int, default=80, help="Subtitle font size")
    parser.add_argument("--sub-position", default="center", choices=["center", "bottom"],
                        help="Subtitle position")
    args = parser.parse_args()

    WORKDIR = args.workdir
    FPS = args.fps
    W, H = 1080, 1920
    OUTPUT = args.output or os.path.join(WORKDIR, "final_reel.mp4")

    # Load timestamps
    ts_file = os.path.join(WORKDIR, "timestamps.json")
    with open(ts_file) as f:
        ts_data = json.load(f)
    words = ts_data.get("words", [])
    duration = ts_data["duration"]
    print(f"Audio: {duration:.1f}s, {len(words)} words")

    # Find Veo clips
    veo_clips = sorted([f for f in os.listdir(WORKDIR) if f.startswith("veo_scene_") and f.endswith(".mp4")])
    n_scenes = len(veo_clips)
    print(f"Veo clips: {n_scenes}")

    if n_scenes == 0:
        print("ERROR: No veo_scene_*.mp4 files found")
        sys.exit(1)

    # Parse scene timings
    if args.scenes:
        scene_times = []
        for pair in args.scenes.split(","):
            start, end = pair.split(":")
            scene_times.append((float(start), float(end)))
    else:
        # Auto: equal segments
        seg = duration / n_scenes
        scene_times = [(i * seg, (i + 1) * seg) for i in range(n_scenes)]

    # Step 1: Stretch each Veo clip to match audio segment
    print("\nStretching clips...")
    for i, (start, end) in enumerate(scene_times):
        target_dur = end - start
        veo_clip = os.path.join(WORKDIR, f"veo_scene_{i+1:02d}.mp4")
        stretched = os.path.join(WORKDIR, f"stretched_{i+1:02d}.mp4")

        # Get actual duration
        probe = subprocess.check_output([
            "ffprobe", "-v", "quiet", "-show_entries", "format=duration",
            "-of", "csv=p=0", veo_clip
        ]).strip()
        actual_dur = float(probe)
        factor = target_dur / actual_dur

        cmd = [
            "ffmpeg", "-y", "-i", veo_clip,
            "-vf", f"setpts={factor}*PTS,scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H}",
            "-t", str(target_dur),
            "-an", "-c:v", "libx264", "-preset", "fast", "-crf", "23",
            "-r", str(FPS), "-pix_fmt", "yuv420p",
            stretched
        ]
        subprocess.run(cmd, capture_output=True, timeout=120)
        size = os.path.getsize(stretched) if os.path.exists(stretched) else 0
        print(f"  Scene {i+1}: {target_dur:.1f}s → {size//1024}KB")

    # Step 2: Concat video
    concat_file = os.path.join(WORKDIR, "concat.txt")
    with open(concat_file, "w") as f:
        for i in range(n_scenes):
            f.write(f"file '{WORKDIR}/stretched_{i+1:02d}.mp4'\n")

    video_only = os.path.join(WORKDIR, "veo_concat.mp4")
    subprocess.run([
        "ffmpeg", "-y", "-f", "concat", "-safe", "0",
        "-i", concat_file, "-c", "copy", video_only
    ], capture_output=True, timeout=60)
    print(f"Concat: {os.path.getsize(video_only)//1024}KB")

    # Step 3: Extract frames + add subtitles via PIL
    FRAMES_DIR = os.path.join(WORKDIR, "frames")
    os.makedirs(FRAMES_DIR, exist_ok=True)

    print("Extracting frames...")
    subprocess.run([
        "ffmpeg", "-y", "-i", video_only,
        "-vf", f"fps={FPS}",
        f"{FRAMES_DIR}/frame_%05d.png"
    ], capture_output=True, timeout=180)

    frame_files = sorted([f for f in os.listdir(FRAMES_DIR) if f.startswith("frame_")])
    total_frames = len(frame_files)
    print(f"Frames: {total_frames}")

    # Font
    font_path = find_font()
    font = ImageFont.truetype(font_path, args.font_size) if font_path else ImageFont.load_default()
    print(f"Font: {font_path}, size {args.font_size}")

    # Add word-by-word subtitles
    print("Adding subtitles...")
    for frame_idx, fname in enumerate(frame_files):
        t = frame_idx / FPS
        img = Image.open(os.path.join(FRAMES_DIR, fname))
        if img.size != (W, H):
            img = img.resize((W, H), Image.LANCZOS)

        draw = ImageDraw.Draw(img)

        # Find current word
        current_word = ""
        for w in words:
            if w["start"] <= t <= w["end"]:
                current_word = w["word"]
                break

        if current_word:
            bbox = draw.textbbox((0, 0), current_word, font=font)
            tw = bbox[2] - bbox[0]
            th = bbox[3] - bbox[1]
            x = (W - tw) // 2

            if args.sub_position == "center":
                y = (H - th) // 2
            else:
                y = H - 220

            # Black outline
            outline = 4
            for dx in range(-outline, outline + 1):
                for dy in range(-outline, outline + 1):
                    if dx * dx + dy * dy <= outline * outline:
                        draw.text((x + dx, y + dy), current_word, font=font, fill=(0, 0, 0))
            # White text
            draw.text((x, y), current_word, font=font, fill=(255, 255, 255))

        img.save(os.path.join(FRAMES_DIR, fname))

        if frame_idx % 200 == 0:
            print(f"  {frame_idx}/{total_frames}")

    print(f"Subtitles done")

    # Step 4: Assemble final
    print("Final assembly...")
    audio_file = os.path.join(WORKDIR, "voiceover.mp3")
    result = subprocess.run([
        "ffmpeg", "-y",
        "-framerate", str(FPS),
        "-i", f"{FRAMES_DIR}/frame_%05d.png",
        "-i", audio_file,
        "-c:v", "libx264", "-preset", "fast", "-crf", "22",
        "-c:a", "aac", "-b:a", "192k",
        "-shortest", "-pix_fmt", "yuv420p",
        OUTPUT
    ], capture_output=True, text=True, timeout=300)

    if result.returncode == 0:
        size = os.path.getsize(OUTPUT)
        print(f"\n🎬 DONE: {OUTPUT} ({size/1024/1024:.1f}MB)")
    else:
        print(f"ERROR: {result.stderr[-300:]}")
        sys.exit(1)

if __name__ == "__main__":
    main()
