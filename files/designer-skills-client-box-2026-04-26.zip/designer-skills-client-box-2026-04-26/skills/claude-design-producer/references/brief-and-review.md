# Brief and Review Templates

Use these templates to keep outputs consistent and useful.

## Default output template

Return sections in this exact order:

# Engine choice
- Claude Design / HyperFrames / Hybrid

# Why this route
- 2-5 bullets explaining why this path fits the job

# Selected preset
- style preset name
- why it fits
- what to keep rigid

# Missing inputs
- only the blockers that actually matter

# Production brief
- Goal
- Audience
- Core message
- Offer / CTA
- Source assets
- Format / aspect ratio
- Target duration
- Visual direction
- Motion direction
- Scene plan
- Risks / constraints

# Prompt pack
- Master prompt
- Optional scene prompts
- Optional revision prompts

# Review loop
- timecode
- issue
- change requested
- keep
- priority

# Delivery checklist
- transcript present
- timestamps present if sync matters
- CTA visible
- safe area respected
- brand consistency checked
- export target confirmed

## Production brief template

Use this structure by default:

## Goal
[What this video must achieve in business terms]

## Audience
[Who it is for and what they already know]

## Core message
[Single main idea]

## CTA
[What the viewer should do next]

## Assets
[MP4, screenshots, website, HTML, docs, logos, voiceover, etc.]

## Format
[16:9 / 9:16 / 1:1 and platform]

## Duration
[Target length]

## Visual direction
[Brand feel, palette, typography, references]

## Motion direction
[Fast / restrained / technical / polished / bold]

## Scene plan
1. Hook
2. Build context
3. Proof / demo / explanation
4. CTA

## Constraints
[What must not happen]

## Risks
[What is weak or missing]

## Master prompt template

Adapt this template instead of writing from scratch each time:

"Create a [format] video for [audience]. The goal is [goal]. The core message is [core message]. Use these assets: [assets]. Apply this style preset: [preset] with these fixed traits: [traits]. Keep the visual direction [visual direction]. Keep the motion direction [motion direction]. Target duration: [duration]. End with this CTA: [CTA]. Respect these constraints: [constraints]. The scene plan is: 1) [hook], 2) [context], 3) [proof/demo], 4) [CTA]. If transcript and timestamps are provided, sync overlays and text to them. If they are missing, keep synchronization broad and do not fake precise word-level timing. Avoid unnecessary decorative motion and keep business clarity first." 

## Timecoded review template

Use this when a draft already exists:

- `00:00-00:03` Hook is too slow → open with stronger text and reduce dead air → keep dark background and first headline style → P1
- `00:04-00:08` Caption covers face → move captions lower / shrink text block → keep wording → P1
- `00:09-00:14` Motion feels noisy → reduce simultaneous animations to one focal action → keep color palette → P2
- `00:15-00:20` CTA lands weak → make CTA larger and visible for at least 2 seconds → keep wording → P1

## Short-form notes

For shorts or reels, add these checks:
- the first 1-2 seconds must hook fast
- face and captions must respect mobile safe areas
- one main message per clip
- no dense paragraphs on screen
- CTA must still be readable at phone size
- every scene should survive silent autoplay
- captions should be punchy, not transcript-dumps
