# Shorts Mode

Use this when the output is a reel, short, TikTok, vertical ad, or cutdown test.

## What changes in shorts mode

Compared with normal video flow, shorts mode is stricter:
- one clip = one idea
- first 1-2 seconds must hook
- every word on screen must earn its place
- readability on a phone matters more than motion cleverness
- payoff must arrive early

## Required checks

Before finalizing the brief, confirm:
- 9:16 target format
- target platform
- target duration range
- transcript availability
- whether the clip will autoplay silently
- CTA vs pure content goal

## Hook patterns

Choose one dominant hook pattern:
- direct claim
- surprising result
- strong pain point
- mistake / myth
- before / after promise
- fast proof snippet

Do not stack multiple hook ideas in one short.

## Structure defaults

### 15-20 sec cut
- 0:00-0:02 hook
- 0:02-0:06 context
- 0:06-0:12 proof / demo / explanation
- 0:12-0:15 CTA or takeaway

### 20-35 sec cut
- 0:00-0:02 hook
- 0:02-0:08 context
- 0:08-0:20 proof / explanation
- 0:20-0:30 payoff
- 0:30-0:35 CTA or takeaway

## Mobile-safe guidance

Keep:
- large text
- strong contrast
- one focal action at a time
- captions clear of the face and UI controls

Avoid:
- paragraphs
- tiny labels
- subtle low-contrast overlays
- multiple competing animations in the same second

## Shorts review loop

When revising a short, compress feedback into these checks:
- hook weaker than it should be?
- first readable frame too slow?
- too many words?
- payoff too late?
- CTA visible and readable?

## Example revision lines

- `00:00-00:01` Hook is too generic → replace with a sharper claim in 4-7 words → keep visual preset → P1
- `00:02-00:05` Setup drags → cut one sentence and reach proof earlier → keep caption style → P1
- `00:06-00:09` Text block is too dense on phone → split into 2 hits with fewer words → keep wording intent → P1
- `00:10-00:13` CTA is too soft → make final action explicit and readable for at least 1.5 seconds → keep brand tone → P2
