# HyperFrames Catalog Shortlist

Use this shortlist before building a custom HyperFrames composition from scratch.

Rule: prefer installing a close-fit block/component first, then restyle, re-time, crop, combine, or rewrite only the parts that matter.

## 1. Best fits for our core use cases

### Promo / launch / brand motion

| Item | Type | Why it matters | Command |
|---|---|---|---|
| `logo-outro` | block | Fast branded ending with logo, tagline, URL | `npx hyperframes add logo-outro` |
| `flash-through-white` | block | Clean energetic scene transition | `npx hyperframes add flash-through-white` |
| `light-leak` | block | Softer cinematic transition | `npx hyperframes add light-leak` |
| `whip-pan` | block | High-energy motion between scenes | `npx hyperframes add whip-pan` |
| `shimmer-sweep` | component | Premium highlight pass over text or UI | `npx hyperframes add shimmer-sweep` |
| `grain-overlay` | component | Adds texture, warmth, less sterile AI feel | `npx hyperframes add grain-overlay` |

### App demo / site demo / product walkthrough

| Item | Type | Why it matters | Command |
|---|---|---|---|
| `app-showcase` | block | Best starting point for multi-screen app/product presentation | `npx hyperframes add app-showcase` |
| `ui-3d-reveal` | block | Good for dramatic UI reveal or onboarding screen intro | `npx hyperframes add ui-3d-reveal` |
| `website-to-hyperframes` | skill route | Turns a real site into a video workflow | use the `website-to-hyperframes` skill |
| `grid-pixelate-wipe` | component | Useful between UI scenes or feature segments | `npx hyperframes add grid-pixelate-wipe` |
| `shimmer-sweep` | component | Good for CTA buttons, active fields, premium UI accents | `npx hyperframes add shimmer-sweep` |

### Data / proof / numbers / case studies

| Item | Type | Why it matters | Command |
|---|---|---|---|
| `data-chart` | block | Best fit for revenue, growth, comparisons, proof screens | `npx hyperframes add data-chart` |
| `flowchart` | block | Good for funnels, decision trees, logic chains, process explainers | `npx hyperframes add flowchart` |

### Social overlays / CTA / follow mechanics

| Item | Type | Why it matters | Command |
|---|---|---|---|
| `instagram-follow` | block | Fast social CTA overlay for IG content | `npx hyperframes add instagram-follow` |
| `tiktok-follow` | block | Vertical CTA for TikTok/reels style cuts | `npx hyperframes add tiktok-follow` |
| `yt-lower-third` | block | Subscribe / host intro / lower-third identity | `npx hyperframes add yt-lower-third` |
| `macos-notification` | block | Great for alert, result, signup, message moments | `npx hyperframes add macos-notification` |
| `x-post` | block | Social proof / tweet screenshot with motion | `npx hyperframes add x-post` |
| `reddit-post` | block | Community/social proof card for stories and explainers | `npx hyperframes add reddit-post` |

## 2. Recommended starter packs by format

### Vertical reel starter pack
- `tiktok-follow`
- `instagram-follow`
- `yt-lower-third`
- `grid-pixelate-wipe`
- `shimmer-sweep`
- `grain-overlay`

### Product / app demo starter pack
- `app-showcase`
- `ui-3d-reveal`
- `whip-pan`
- `flash-through-white`
- `shimmer-sweep`

### Case study / proof / sales video starter pack
- `data-chart`
- `flowchart`
- `macos-notification`
- `x-post`
- `logo-outro`

## 3. Default mapping for our work

| Our task | Start from |
|---|---|
| Reels with CTA | `tiktok-follow`, `instagram-follow`, `yt-lower-third` |
| Website promo video | `website-to-hyperframes` + `app-showcase` + selected transition block |
| App demo | `app-showcase` + `ui-3d-reveal` |
| Sales proof / dashboards | `data-chart` |
| Funnel / system / workflow explainer | `flowchart` |
| Outro / brand finish | `logo-outro` |

## 4. How to use the shortlist

1. Pick the closest item from this file.
2. Install it.
3. Preview the raw result.
4. Replace text, assets, colors, typography, and timings.
5. Only if the block fights the task badly, rewrite or build custom.

## 5. House-style adaptation notes

For our default aesthetic, adapt installed catalog items like this:
- dark canvas first
- sharp contrast
- restrained lime / acid accent
- less "template polish", more editorial / brutalist intent
- bigger typography, fewer words
- strong CTA, no decorative clutter

## 6. Avoid these mistakes

- Do not rebuild charts, lower-thirds, social follow cards, or logo outros from zero if the catalog already covers 80 percent.
- Do not keep stock colors and fonts after install when the task is brand-sensitive.
- Do not overload one reel with too many catalog blocks at once.
- Do not use flashy transitions between every scene. Use them as emphasis, not wallpaper.
