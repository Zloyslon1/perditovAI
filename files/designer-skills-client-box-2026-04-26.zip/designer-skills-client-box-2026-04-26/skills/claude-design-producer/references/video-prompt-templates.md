# Video Prompt Templates

Use these when the user already knows the video type and needs a fast first draft.

## 1) Promo / Launch Video

Best for:
- new product drops
- launch weeks
- sales pushes

Prompt skeleton:
"Create a [format] promo video for [audience]. The goal is to make them understand [offer] and take [CTA]. Use the [preset] preset. Open with a hard hook that names the pain or opportunity. Then show the transformation, the proof, and the offer. Keep copy short and high-contrast. Duration: [duration]. Avoid fluffy hype language and avoid over-animating every line."

Scene bias:
- Hook
- Problem / opportunity
- Proof or result
- Offer
- CTA

## 2) Talking-Head + Overlays

Best for:
- expert clips
- founder videos
- testimonial upgrades

Prompt skeleton:
"Create a [format] talking-head video with overlays for [audience]. Use the [preset] preset. Keep the speaker's face readable and never cover key facial areas. Use captions and overlays only to reinforce the strongest lines. Sync to the provided transcript and timestamps where possible. Keep motion restrained and make the CTA land cleanly at the end. Duration: [duration]."

Scene bias:
- Hook line
- 2-4 supporting beats
- CTA or takeaway

## 3) Educational Explainer

Best for:
- teaching frameworks
- process explainers
- myth-busting clips

Prompt skeleton:
"Create a [format] educational explainer for [audience]. The goal is to teach [topic] clearly and fast. Use the [preset] preset. Break the message into a clean sequence: hook, context, explanation, proof/example, takeaway. Prefer clarity over spectacle. Keep text blocks short, diagrams simple, and transitions intentional. Duration: [duration]."

Scene bias:
- Hook question or claim
- Context
- Explanation
- Example or proof
- Summary takeaway

## 4) Product / App Demo

Best for:
- SaaS walkthroughs
- dashboard demos
- feature showcases

Prompt skeleton:
"Create a [format] product demo for [audience]. Use the [preset] preset. The interface must remain readable at all times. Build scenes around real user actions: where to click, what changes, why it matters. Use minimal callouts, clear zooms, and structured sequencing. If transcript and timestamps exist, align overlays to the narration. Duration: [duration]. End on [CTA]."

Scene bias:
- Outcome preview
- Problem context
- Step-by-step product action
- Benefit or proof
- CTA

## 5) Website-to-Video

Best for:
- turning a landing page into a motion draft
- quick concept passes from existing site structure

Prompt skeleton:
"Create a [format] video using [website/assets] as the source structure. Use the [preset] preset. Translate the strongest sections into motion scenes without copying every block blindly. Preserve hierarchy, simplify clutter, and keep one message per scene. Start with the best headline or promise, then move through proof, offer, and CTA. Duration: [duration]."

Scene bias:
- Best page promise first
- Key supporting section
- Proof / social proof / result
- Offer block
- CTA block

## 6) Shorts / Reels Cutdown

Best for:
- repurposing longer content
- hook testing
- vertical ad variations

Prompt skeleton:
"Create a 9:16 short video for [platform] using the [preset] preset. The first 1-2 seconds must hook immediately. Keep one dominant message only. Use large mobile-safe typography, short captions, and fast proof or payoff. Remove setup that does not earn its place. Duration: [duration]. End with a direct CTA or takeaway."

Scene bias:
- Hook
- Fast context
- Proof or payoff
- CTA / takeaway
