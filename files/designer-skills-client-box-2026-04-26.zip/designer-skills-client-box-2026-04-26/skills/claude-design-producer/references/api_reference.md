# External Reference Map

Use these references when the task moves from workflow design into actual production.

## Official HyperFrames ecosystem

Foundation stack discovered during research:
- `heygen-com/hyperframes@hyperframes`
- `heygen-com/hyperframes@hyperframes-cli`
- `heygen-com/hyperframes@gsap`
- `heygen-com/hyperframes@hyperframes-registry`
- `heygen-com/hyperframes@website-to-hyperframes`
- `heygen-com/hyperframes@hyperframes-compose`

## What to load when

### Need composition rules or HTML-video logic
Load the official HyperFrames skill or docs first.

### Need rendering / CLI / transcript workflow
Load `hyperframes-cli` or the relevant project docs.

### Need motion composition patterns
Load the registry / GSAP references.

## Public custom reference worth studying

GitHub repo found during research:
- `alecramos-sudo/hyperframes-skill`

Useful ideas seen there:
- house style layer
- visual style presets
- patterns library
- palettes and references

Treat this as inspiration, not a source to copy blindly.

## Claude Design note

No strong canonical public skill dedicated specifically to Claude Design video workflow was found in the same quality tier as the official HyperFrames ecosystem.

Implication:
- use HyperFrames as the execution foundation
- keep Claude Design guidance inside this wrapper skill as workflow and prompt architecture
