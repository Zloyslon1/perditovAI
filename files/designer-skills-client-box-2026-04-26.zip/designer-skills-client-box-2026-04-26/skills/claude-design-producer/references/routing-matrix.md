# Routing Matrix

Use this table when choosing between Claude Design, HyperFrames, or a hybrid flow.

| Situation | Preferred route | Why |
|---|---|---|
| Fast branded first draft | Claude Design | Quick concepting and motion direction |
| Talking-head with basic overlays | Claude Design | Fast first pass, low setup |
| Website or HTML turned into a motion promo | Claude Design first, then Hybrid if needed | Good for rapid visual translation, then controlled rebuild if the concept sticks |
| Product or app demo with multiple scenes | HyperFrames | Better control over compositions and repeatability |
| Precise subtitle or overlay sync | HyperFrames | Better for structured timing and controlled revisions |
| Reusable production system for many videos | HyperFrames | HTML pipeline scales better than one-off manual prompting |
| One-off experimental social cut | Claude Design | Faster to test ideas cheaply |
| Final polished version after a rough first pass | Hybrid | Fast exploration first, controlled production second |

## Rules of thumb

### Prefer Claude Design when
- you need speed
- you need a concept or rough first version
- export polish is less important than iteration speed
- the user wants to see possibilities quickly

### Prefer HyperFrames when
- you need deterministic structure
- the same style or motion system will be reused
- scene control matters
- review cycles will be heavy
- the final deliverable must survive repeated changes cleanly

### Escalate to hybrid when
- the first-pass direction is approved but the draft needs more control
- Claude Design gets the look right but not the execution
- the user wants a reusable system, not just one video
