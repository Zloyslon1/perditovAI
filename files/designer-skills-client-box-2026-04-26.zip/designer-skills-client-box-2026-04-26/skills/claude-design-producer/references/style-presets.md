# Style Presets

Use these presets when the user wants fast alignment without a long art-direction session.

Return the preset name explicitly in the output as `Selected preset`.

## 1) BAZA Dark Brutalist

Use when:
- launch videos for BAZA / workbook / AI-education products
- direct-response promos
- punchy explainers with hard contrast

Keep:
- dark graphite or black background
- oversized uppercase typography
- lime accent, but only in sharp hits
- rigid grid, dense blocks, minimal softness
- short, commanding text

Avoid:
- glossy startup gradients
- playful stickers or soft pastel motion
- too many simultaneous animations

Motion feel:
- hard cuts
- assertive reveals
- deliberate pacing, not frantic chaos

## 2) Agency Clean Performance

Use when:
- case studies
- client-facing launch videos
- offer explainers that need trust and clarity

Keep:
- dark or neutral base
- crisp sans typography
- one accent color max
- clean charts, cards, proof points
- calm polished transitions

Avoid:
- meme energy
- overloaded motion backgrounds
- fake cinematic drama

Motion feel:
- precise
- expensive
- conversion-oriented

## 3) Product Demo Control Room

Use when:
- SaaS or app demos
- dashboard walkthroughs
- feature explainers with UI focus

Keep:
- interface readable at all times
- zooms only when they clarify action
- labels and callouts minimal and exact
- structured scene hierarchy

Avoid:
- covering UI with giant overlays
- flashy transitions that hide navigation logic
- decorative motion that competes with the product

Motion feel:
- technical
- guided
- repeatable

## 4) Founder Talking-Head Overlay

Use when:
- talking-head clips with captions and overlays
- educational authority content
- personal brand explainers

Keep:
- face clear and dominant
- captions readable and safely placed
- overlays used only to reinforce key points
- direct, spoken-language phrasing

Avoid:
- caption blocks over the eyes or mouth
- dense lower-thirds all the time
- decorative widgets that distract from speech

Motion feel:
- supportive
- confident
- restrained

## 5) Social Hook Test

Use when:
- reels, shorts, TikTok tests
- headline-first performance tests
- cutdowns for multiple hooks

Keep:
- one brutal hook
- one idea per clip
- giant first-frame readability
- payoff or proof quickly after the hook

Avoid:
- long intros
- multi-message scripts
- subtle typography that dies on mobile

Motion feel:
- immediate
- clean
- phone-first

## 6) Educational Screen Essay

Use when:
- mini lessons
- concept breakdowns
- framework explainers

Keep:
- clear sectioning
- simple diagrams or text stacks
- strong knowledge hierarchy
- slower pacing than promo videos

Avoid:
- hype motion for serious material
- too many color shifts
- scene density that kills comprehension

Motion feel:
- structured
- didactic
- calm but sharp
