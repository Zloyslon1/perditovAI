---
name: claude-design-producer
description: Build and iterate AI-assisted video production workflows using Claude Design and HyperFrames for promo videos, launch videos, talking-head overlays, educational explainers, product or app demos, website-to-video conversions, and short-form tests. Use when the agent needs to decide between Claude Design vs HyperFrames, gather transcript/timestamps/style inputs, create structured video briefs, generate paste-ready prompt packs, or run timecoded revision loops for motion-heavy video work.
---

# Claude Design Producer

Use this skill to turn vague video requests into a repeatable production workflow. The job is not to say "AI can make videos." The job is to choose the right engine, demand the right inputs, produce a tight brief, and keep revisions disciplined.

## Default workflow

1. Classify the video task.
2. Gather the non-negotiable inputs.
3. Pick a route and a house-style preset.
4. Produce a brief and a paste-ready prompt pack.
5. If needed, switch into shorts mode.
6. Run revisions with timecoded feedback.

## 1) Classify the task

Put the request into one of these buckets before doing anything else:
- talking-head + overlays
- promo / launch video
- educational explainer
- product / app demo
- website-to-video
- short / reel test

Read `references/video-prompt-templates.md` when you need a ready-made structure for the selected bucket.

If the user asks for more than one deliverable, split them explicitly. Example: "one landscape explainer + one vertical reel cutdown".

## 2) Gather non-negotiable inputs

Do not start from "make it engaging" alone. Collect or explicitly note what is missing.

Minimum required inputs:
- goal of the video
- audience
- source assets (video, HTML, screenshots, site, docs)
- transcript
- timestamps if sync matters
- aspect ratio and target platform
- desired duration
- CTA or ending action
- visual style / brand system
- reference examples if the user has them

If critical inputs are missing, ask only for the smallest missing set that blocks progress.

## 3) Route to the correct engine

### Choose Claude Design when
- speed matters more than deterministic control
- the user needs a fast branded first pass
- the source is a website, deck-like structure, or simple MP4
- the output is motion graphics, overlays, titles, or a quick concept video
- manual export or handoff is acceptable

### Choose HyperFrames when
- timing must be precise
- HTML should remain the source of truth
- captions or subtitle sync matter
- the task is a product demo or multi-scene composition
- the user expects repeated iterations
- code-level control, repeatability, or render reliability matter

### Choose hybrid when
- Claude Design can generate the first visual direction quickly
- HyperFrames is better for the final controlled version

Default bias:
- first-pass concept and fast branded motion → Claude Design
- production control and repeatable render pipeline → HyperFrames

Read `references/routing-matrix.md` when the choice is not obvious.

## 4) Produce the brief and prompt pack

Always output these sections in this order:
1. Engine choice
2. Why this route
3. Selected preset
4. Missing inputs
5. Production brief
6. Prompt pack
7. Review loop
8. Delivery checklist

Read `references/brief-and-review.md` and follow its templates.
If the user needs a house style, read `references/style-presets.md` and pick the closest preset instead of inventing one from scratch.

## 5) Shorts mode

When the deliverable is a reel, short, TikTok, story cutdown, or vertical ad test, read `references/shorts-mode.md` before finalizing the brief.

Use shorts mode to enforce:
- hook in the first 1-2 seconds
- one dominant idea per clip
- safe mobile composition
- fewer words on screen
- a shorter, more brutal review loop

## 6) Revision loop

Do not accept vague feedback like "make it better" as the only revision input when a timecoded video already exists.

Convert feedback into this structure:
- timecode
- what is wrong
- what to change
- what to preserve
- priority

If there is no render yet, use scene-level revisions instead of timecoded revisions.

## Quality rules

- Optimize for business clarity first, spectacle second.
- Do not over-animate simple messages.
- Do not let captions or graphics cover the speaker's face unless explicitly requested.
- Do not bury the CTA under decorative motion.
- Do not promise tight sync without a transcript and timestamps.
- Do not present AI output as finished craft when it is clearly a first pass.
- For shorts, protect the hook in the first 1-2 seconds and keep the composition readable on mobile.
- For product demos, do not let motion graphics obscure the interface being demonstrated.

## House style defaults

Use these defaults unless the user gives a stronger visual direction:
- dark canvas
- sharp, high-contrast typography
- restrained lime or acid accent
- direct, non-hype messaging
- motion that feels deliberate, not chaotic

If the user already has a brand system, use it instead of these defaults.
If the task needs a more opinionated art direction, load `references/style-presets.md` and choose a named preset.

## Execution guidance

### For Claude Design workflows
Prepare a paste-ready prompt pack before touching the UI. If transcripts or timestamps are missing, say that sync quality will be limited.
Prefer concise direction blocks: goal, scene structure, style preset, constraints, CTA.

### For HyperFrames workflows
Use HyperFrames as a controlled HTML-video pipeline. Prefer reusable scene logic, explicit compositions, and deterministic review cycles over one-off flashy hacks.
Use named scene roles and reusable modules when the user wants multiple variants or recurring series.
Before designing a custom composition from scratch, check whether the official HyperFrames catalog already has a close-fit block or component for the job, especially for charts, social overlays, lower thirds, logo outros, transitions, UI reveals, and website-to-video patterns.
Treat catalog items as production building blocks: install first, then restyle, re-time, and adapt them to the user's brand and message.
Read `references/hyperframes-catalog-shortlist.md` when the task is reel/short, promo, app demo, website-to-video, CTA overlay, chart, social proof, or branded outro work.

## Boundaries

This skill is for production workflow and prompt architecture. It is not a generic filmmaking theory skill and not a replacement for brand strategy, copywriting, or taste.

When the task shifts into code-heavy HyperFrames implementation, load the official HyperFrames skill stack if available.
