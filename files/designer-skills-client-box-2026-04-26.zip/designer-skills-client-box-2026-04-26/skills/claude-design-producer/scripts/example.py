#!/usr/bin/env python3
"""
Generate a clean markdown review loop skeleton for video revisions.
Usage:
  python3 scripts/example.py --mode timecoded
  python3 scripts/example.py --mode scene
"""

import argparse

TIMECODED = """# Review loop\n\n- `00:00-00:03` Issue → Change requested → Keep → P1\n- `00:04-00:08` Issue → Change requested → Keep → P1\n- `00:09-00:14` Issue → Change requested → Keep → P2\n"""

SCENE = """# Review loop\n\n## Hook\n- Issue → Change requested → Keep → P1\n\n## Build\n- Issue → Change requested → Keep → P1\n\n## Proof / Demo\n- Issue → Change requested → Keep → P2\n\n## CTA\n- Issue → Change requested → Keep → P1\n"""


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["timecoded", "scene"], default="timecoded")
    args = parser.parse_args()
    print(TIMECODED if args.mode == "timecoded" else SCENE)


if __name__ == "__main__":
    main()
